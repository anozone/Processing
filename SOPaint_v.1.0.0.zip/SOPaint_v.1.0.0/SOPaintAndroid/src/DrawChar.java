package jp.ad.SOPaint.Android;
import processing.core.*;


/**
* 親クラス:
* @author YM
* @param float startPointX :初期位置X
* @param float startPointY :初期位置Y
* @param float endPointX :終了位置X
* @param float endPointY :終了位置Y
* @param float halfPointX : Start~endの中間X
* @param float halfPointY : Start~endの中間Y
* @param float halfSizeX : 半分の値X
* @param float halfSizeY : 半分の値Y
* @param float dSize : デフォルト文字サイズ
* @param float cSize : 描画円のサイズ
*/
public class DrawChar extends PApplet implements ThreadBreak
{

 /**
	 *
	 */
	private static final long serialVersionUID = 1L;
protected float startPointX;
 protected float startPointY;
 protected float endPointX;
 protected float endPointY;
 protected float halfPointX;
 protected float halfPointY;
 protected float halfSizeX;
 protected float halfSizeY;
 protected float dSize;
 protected float cSize;
 protected float DEFAULT_SIZE = 200;
 private int sec = 10;
 ThreadHandle th;
 PApplet pa;


  /** ---------------------------------------
  * DrawChar()
  * コンストラクタ
  * @author YM 2012/06/21
  *-----------------------------------------*/
 public DrawChar(ThreadHandle th, PApplet applet)
 {
    this.th = th;
    pa = applet;
 }

  /** ---------------------------------------
  * float getStartPointX()
  * 開始位置Xを取得する
  * @author YM 2012/06/06
  * @return float
  *-----------------------------------------*/
  public float getStartPointX()
 {
   return startPointX;
 }

  /** ---------------------------------------
  * float getStartPointY()
  * 開始位置Yを取得する
  * @author YM 2012/06/06
  * @return float
  *-----------------------------------------*/
 public float getStartPointY()
 {
   return startPointY;
 }

   /** ---------------------------------------
  * float getEndPointX()
  * 終了位置Xを取得する
  * @author YM 2012/06/14
  * @return float
  *-----------------------------------------*/
 public float getEndPointX()
 {
   return endPointX;
 }

   /** ---------------------------------------
  * float getEndPointY()
  * 終了位置Yを取得する
  * @author YM 2012/06/14
  * @return float
  *-----------------------------------------*/
 public float getEndPointY()
 {
   return endPointY;
 }

  /** ---------------------------------------
  * float getHalfPointX()
  * start~endまでの中間距離Xを取得する
  * @author YM 2012/06/14
  * @return float
  *-----------------------------------------*/
 public float getHalfPointX()
 {
   return halfPointX;
 }

    /** ---------------------------------------
  * float getHalfPointY()
  * start~endまでの中間距離Yを取得する
  * @author YM 2012/06/14
  * @return float
  *-----------------------------------------*/
 public float getHalfPointY()
 {
   return halfPointY;
 }

    /** ---------------------------------------
  * float getHalfSizeX()
  * start~end間の中間のサイズXを取得する
  * @author YM 2012/06/14
  * @return float
  *-----------------------------------------*/
 public float getHalfSizeX()
 {
   return halfSizeX;
 }

    /** ---------------------------------------
  * float getHalfSizeY()
  * start~end間の中間サイズYを取得する
  * @author YM 2012/06/14
  * @return float
  *-----------------------------------------*/
 public float getHalfSizeY()
 {
   return halfSizeY;
 }

    /** ---------------------------------------
  * float getDrawSize()
  * 描画する文字の大きさを取得する
  * @author YM 2012/06/14
  * @return float
  *-----------------------------------------*/
 public float getDrawSize()
 {
   return dSize;
 }

    /** ---------------------------------------
  * float getCircleSize()
  * 描画する文字の線のサイズを取得する
  * @author YM 2012/06/14
  * @return float
  *-----------------------------------------*/
 public float getCircleSize()
 {
   return cSize;
 }

     /*--------------------------------------------------------
  // void drawLine(float x, float y,float dSize, float cSize)
  // @param float x      描画位置情報(縦)
  //        float y      描画位置情報(横)
  //        float dSize  文字の大きさ
  //        float cSize  線(描画の点)の大きさ
  // @return  なし
  // @note    点を描画、描画処理の共通化
  --------------------------------------------------------*/
  public void drawLine(float x, float y,float cSize){
        pa.fill(255,255,255);
        pa.ellipse(x, y, cSize, cSize);
        th.sopSleep(sec);
  }

   /** ---------------------------------------
   * drawLine(float, float, float, int)
   * 点を描画（描画速度変更）
   * @author YM 2012/06/21
   * @param x 描画開始位置座標X
   * @param y 描画開始位置座標Y
   * @param cSize 線の太さ
   * @param sleep 待機時間(ms)
   *-----------------------------------------*/
 public void drawLine(float x, float y, float cSize, int sleep) {
    pa.fill(255,255,255);
    pa.ellipse(x, y, cSize, cSize);
    th.sopSleep(sleep);
  }
   /** ---------------------------------------
   * drawLine(float, float, float, int, int, int)
   * 点を描画（色指定変更）
   * @author YM 2012/06/21
   * @param x 描画開始位置座標X
   * @param y 描画開始位置座標Y
   * @param cSize 線の太さ
   * @param r 線色（赤）
   * @param g 線色（緑）
   * @param b 線色（青）
   *-----------------------------------------*/
 public void drawLine(float x, float y, float cSize, int r, int g, int b) {
    pa.fill(r, g, b);
    pa.ellipse(x, y, cSize, cSize);
    th.sopSleep(10);
  }
     /** ---------------------------------------
   * drawLine(float, float, float, int, int)
   * 点を描画（描画速度・色指定変更）
   * @author YM 2012/06/21
   * @param x 描画開始位置座標X
   * @param y 描画開始位置座標Y
   * @param cSize 線の太さ
   * @param sleep 待機時間(ms)
   * @param gray 線色（白黒）
   *-----------------------------------------*/
  public void drawLine(float x, float y, float cSize, int sleep, int gray) {
    pa.fill(gray);
    pa.ellipse(x, y, cSize, cSize);
    th.sopSleep(sleep);
  }
   /** ---------------------------------------
   * drawLine(float, float, float, int, int, int, int)
   * 点を描画（描画速度・色指定変更）
   * @author YM 2012/06/21
   * @param x 描画開始位置座標X
   * @param y 描画開始位置座標Y
   * @param cSize 線の太さ
   * @param sleep 待機時間(ms)
   * @param r 線色（赤）
   * @param g 線色（緑）
   * @param b 線色（青）
   *-----------------------------------------*/
  public void drawLine(float x, float y, float cSize, int sleep, int r, int g, int b) {
    pa.fill(r, g, b);
    pa.ellipse(x, y, cSize, cSize);
    th.sopSleep(sleep);
  }

   /** ---------------------------------------
   * testFrame()
   * 描画範囲の枠を可視化
   * @author YM 2012/06/21
   *-----------------------------------------*/
 protected void testFrame() {
    float startx = getStartPointX();
    float starty = getStartPointY();
    float endx = getEndPointX();
    float endy = getEndPointY();
    float counter = 3;
    int r = 150;
    int g = 50;
    int b = 0;
    for (; startx < endx; startx=startx+counter) {
        drawLine(startx, starty, cSize, 0, r, g, b);
       if (breakCheck()) {return;}
    }
    for (; starty < endy; starty=starty+counter) {
        drawLine(startx, starty, cSize, 0, r, g, b);
        if (breakCheck()) {return;}
    }
    endx = getStartPointX();
    for (; startx > endx; startx=startx-counter) {
        drawLine(startx, starty, cSize, 0, r, g, b);
       if (breakCheck()) {return;}
    }
    endy = getStartPointY();
    for (; starty > endy; starty=starty-counter) {
        drawLine(startx, starty, cSize, 0, r, g, b);
     if (breakCheck()) {return;}
    }
  }

  boolean breakFlag = false;
   /** ---------------------------------------
   * setBreakCheck(boolean flag)
   * Threadが途中でキャンセルされた場合に呼び出される
   * @author KR 2012/06/27
   *-----------------------------------------*/
  public void setBreakCheck(boolean flag) {
    breakFlag = flag;
  }
     /** ---------------------------------------
   * breakCheck
   * Threadが途中でキャンセルされたかをチェック
   * @author YM 2012/06/26
   *-----------------------------------------*/
  public boolean breakCheck() {
    return breakFlag;
  }

  public void setSleepSec(int s)
  {
    sec = s;
  }

  /**-----------------------------------------
   * public void println(Strint str)
   * コンソールにメッセージを表示させる
   * @param str 表示する文字列
   */
 /* public void println(String str) {
	  System.out.println(str);
}*/

}

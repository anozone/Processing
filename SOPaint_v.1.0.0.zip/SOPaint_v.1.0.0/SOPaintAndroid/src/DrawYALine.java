package jp.ad.SOPaint.Android;

import processing.core.PApplet;

/** ---------------------------------------
 * や行描画クラス
 * @author YM 2012/06/14-18
 *-----------------------------------------*/
class DrawYALine extends DrawChar {
  /**
	 *
	 */
	private static final long serialVersionUID = 1L;

/** ---------------------------------------
   * DrawYALine(float, float, float, float)
   * コンストラクタ
   * @author YM 2012/06/14
   * @param x 描画開始位置座標X
   * @param y 描画開始位置座標Y
   * @param d 描画する大きさ
   * @param c 線の太さ
   *-----------------------------------------*/
  public DrawYALine (float x, float y, float d, float c, ThreadHandle th, PApplet pa)
  {
	super(th, pa);
    startPointX = x;
    startPointY = y;
    dSize = d;
    cSize = c;
    endPointX = startPointX + dSize;              //例 100 + 100 = 200
    endPointY = startPointY + dSize;
    halfSizeX = (endPointX - startPointX) / 2;    // (200 - 100) / 2 = 50
    halfSizeY = (endPointY - startPointY) / 2;
    halfPointX = startPointX + halfSizeX;         // 100 + 50 = 150
    halfPointY = startPointY + halfSizeY;
  }

  /** ---------------------------------------
   * void drawCharYA()
   * ひらがな「や」の書き順を描画する
   * @author YM 2012/06/14
   * @return なし
   *-----------------------------------------*/
 public void drawCharYA()
  {
    float startx = getStartPointX();
    float starty = getHalfPointY();
    float endx = getEndPointX() - (getHalfSizeX() / 2);
    float endy = halfPointY + (halfSizeY / 4);
    float counter = 3;
    float lx = 0;

    try {
      //書き順1
      for (; startx < endx; startx=startx+counter, starty=starty-(float)0.3) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) {
          return;
        }
      }

      //書き順1-2
      endx = startx - 1;
      for (;startx > endx; startx=startx+counter-lx, starty=starty+counter) {
        drawLine(startx, starty, cSize);
        lx = lx + (float)0.3;
        if (breakCheck()) {
          return;
        }
      }

      //書き順2
      startx = halfPointX;
      starty = halfPointY - (halfSizeY / 2);
      lx = 0;
      for (;starty < endy; startx=startx+1-lx, starty=starty+counter) {
        drawLine(startx, starty, cSize);
        lx = lx + (float)0.05;
        if (breakCheck()) {return;}
      }

      //書き順3
      startx = halfPointX - (halfSizeX / 2);
      starty = halfPointY - (halfSizeY / 2);
      endy = endPointY;
      for (;starty < endPointY;startx=startx+1, starty=starty+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) {return;}
      }
    }
    catch (ArrayIndexOutOfBoundsException e) {
      println("OutOfBoundsError");
      e.printStackTrace();
    }
    catch (NullPointerException e) {
      println("NullPointerError");
      e.printStackTrace();
    }
    catch (OutOfMemoryError e) {
      println("OutOfMemoryError");
      e.printStackTrace();
    }
    catch (Exception e) {
      println("CriticalError");
      e.printStackTrace();
    }
  }

  /** ---------------------------------------
   * void drawCharYU()
   * ひらがな「ゆ」の書き順を描画する
   * @author YM 2012/06/14
   * @return なし
   *-----------------------------------------*/
  public void drawCharYU()
  {
    float startx = getStartPointX() + (getHalfSizeX() / 4);
    float starty = getStartPointY() + (getHalfSizeY() / 2);
    float endx = getEndPointX() - (getHalfSizeX() / 2);
    float endy = getEndPointY() - (getHalfSizeY() / (float)1.5);
    float counter = 3;
    float lx = 0;
    float ly = 0;

    try {
      //書き順1
      for (; starty < endy;  starty=starty+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) {   return;  }
      }

      //書き順2

      endy =  starty - ((starty -( getStartPointY() +  (getHalfSizeY() / 2))) / 2);
      for (; starty > endy;startx = startx+2, starty = starty-counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) {    return;      }
      }

      endx = getHalfPointX() + (getHalfSizeX() / 2);
      for (; startx < endx; startx=startx+counter, starty=starty-2+ly) {
        drawLine(startx, starty, cSize);
        ly = ly + (float)0.05;
        if (breakCheck()) { return; }
      }

      //書き順2-2
      endx = getHalfPointX() - (getHalfSizeX() / 4);
      for (; startx > endx; startx=startx+counter-lx, starty=starty-2+ly) {
        drawLine(startx, starty, cSize);
        if (starty < endy) {
          ly = ly +(float) 0.05;
        }
        else {
          ly = ly -(float) 0.03;
        }
        lx = lx +(float) 0.05;
        if (breakCheck()) { return; }
      }

      //書き順3
      startx = getHalfPointX()+ (getHalfSizeX() / 4);
      starty = getStartPointY();
      endy = getEndPointY();// + (getHalfSizeY() / 4);
      lx = 0;
      for (; starty < endy;starty = starty+counter, startx = startx + 1 - lx) {
        drawLine(startx, starty, cSize);
        lx = lx + (float)0.03;
        if (breakCheck()) {return;}
      }
    } catch (ArrayIndexOutOfBoundsException e) {
      println("OutOfBoundsError");
      e.printStackTrace();
    }
    catch (NullPointerException e) {
      println("NullPointerError");
      e.printStackTrace();
    }
    catch (OutOfMemoryError e) {
      println("OutOfMemoryError");
      e.printStackTrace();
    }
    catch (Exception e) {
      println("CriticalError");
      e.printStackTrace();
    }
  }

    /** ---------------------------------------
   * void drawCharYO()
   * ひらがな「よ」の書き順を描画する
   * @author YM 2012/06/18
   * @return なし
   *-----------------------------------------*/
  public void drawCharYO()
  {
    float startx = getHalfPointX();
    float starty = getHalfPointY() - (getHalfSizeY() / 4);
    float endx = getEndPointX() - (getHalfSizeX() / 4);
    float endy = 0;
    float counter = 3;
    float lx = 0;
    float ly = 0;

    try {
      //書き順1
      for (; startx < endx;  startx=startx+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) {   return;  }
      }

      //書き順2
      startx = getHalfPointX();
      starty = getStartPointY();
      endy = getEndPointY() - (getHalfSizeY() / 2);
      for (; starty < endy; starty=starty+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) {   return;  }
      }


      //書き順2-2
      endy = getEndPointY();
      lx = 0;
      ly = 0;
      float xcntr = 0;
      float cshy = starty;      //折り返し地点Y（下に振り下ろすポイント
      float cshx = startx + 1;  //折り返し制御（Xが現在地含む左側にいる場合
      for (; starty < endy; starty=starty+counter-ly, startx=startx-xcntr + lx) {
        drawLine(startx, starty, cSize);
        //よの、○部分を構成：xの微調整
        if(xcntr < counter+1.5) xcntr = xcntr + (float)0.5;
        lx = lx +(float) 0.1;
        //よの、○部分を構成：振り下ろすタイミング調整
        if(starty >= cshy && startx <= cshx ) ly = ly +(float) 0.1;  //○の上部にくるまでは減速
        else ly = ly -(float) 0.2;                                   //○上部にきたため、振り下ろし
        if (breakCheck()) {   return;  }
      }

    } catch (ArrayIndexOutOfBoundsException e) {
      println("OutOfBoundsError");
      e.printStackTrace();
    }
    catch (NullPointerException e) {
      println("NullPointerError");
      e.printStackTrace();
    }
    catch (OutOfMemoryError e) {
      println("OutOfMemoryError");
      e.printStackTrace();
    }
    catch (Exception e) {
      println("CriticalError");
      e.printStackTrace();
    }
  }
  //class end

}


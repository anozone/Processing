package jp.ad.SOPaint.Android;

/** ---------------------------------------
 * スレッドブレイクチェックインターフェース
 * @author YM 2012/06/26
 *-----------------------------------------*/
public interface ThreadBreak {
	boolean breakCheck();
}

package jp.ad.SOPaint.Android;

import processing.core.PApplet;
//--------------------------------------------------------
//「あ行」描画クラス
//--------------------------------------------------------
class DrawALine extends DrawChar{

//コンストラクタ
public DrawALine (float x, float y, float d, float c, ThreadHandle th, PApplet pa)
{
	super(th, pa);
startPointX = x;
startPointY = y;
endPointX = startPointX + d;              //例 100 + 100 = 200
endPointY = startPointY + d;
halfSizeX = (endPointX - startPointX) / 2;    // (200 - 100) / 2 = 50
halfSizeY = (endPointY - startPointY) / 2;
halfPointX = startPointX + halfSizeX;         // 100 + 50 = 150
halfPointY = startPointY + halfSizeY;
dSize = d;
cSize = c;
}

/*--------------------------------------------------------
//void drawCharA()
//@return  なし
//@note    ひらがな「あ」の書き順を描画する
--------------------------------------------------------*/
public void drawCharA()
{

  float fontsize=1;
  //フォントサイズの変更
  if(DEFAULT_SIZE > dSize){
     fontsize = dSize/DEFAULT_SIZE;
     startPointX = startPointX*fontsize;
     startPointY = startPointY*fontsize;
  }

  //--- 書き順 1 ---//
  float start  = getStartPointX()+getHalfPointX() / 2 ;
  float end    = getHalfPointX()+getHalfSizeX() / 2;
  float nextx  = getStartPointX()+getHalfSizeX() / 4 ;
  float nexty  = getStartPointY()+getHalfSizeY()  / 4 ;
  for(;nextx <= end ;nextx=nextx+3,nexty=nexty-(float)0.1){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  //--- 書き順 2 ---///
  start  = getStartPointY() ;
  end    = endPointY;
  nextx  = getHalfPointX()-getHalfSizeX()/4;
  nexty  = start;
  for(float i=0 ;nexty <= end ;nexty=nexty+3){
    nextx = getHalfPointY() > nexty ? nextx-(float)0.2 : nextx+(i=i+(float)0.05);
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  //--- 書き順 3-1 ---///
  start  = getStartPointX()+getHalfSizeX()+getHalfSizeX()/2;
  end    = endPointY;
  nextx  = start;
  nexty  = getStartPointY()+getHalfSizeY()-getHalfSizeY()/2;
  for(;nexty <= end ;nexty=nexty+(3*fontsize),nextx=nextx-(2*fontsize)){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  nextx = getHalfPointX()-getHalfSizeX()/2;
  nexty = getHalfPointY()+getHalfSizeY()/2+getHalfSizeY()/8;
  int deg = 90;
  int r   = 40;
  int x   = 0;
  int y   = 0;
  for(;deg <= 180;deg++){
     float rad = (float)(Math.toRadians(deg));
     x = (int)((nextx)+r*Math.cos(rad));  //角度から円周上のx座標を計算
     y = (int)((nexty)+r*Math.sin(rad));  //角度から円周上のy座標を計算
     drawLine(x, y, cSize);
     if(breakCheck()){return;}
  }

  nexty = y;
  nextx = x;
  end   = getHalfPointY()+getHalfSizeY()/2;
  for(;nexty >= end ;nexty=nexty-((float)1*fontsize)){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  nextx = getHalfPointX()-getHalfSizeX()/2;
   deg = 180;
   r   = 40;
   x   = 0;
   y   = 0;
  for(;deg <= 270;deg++){
     float rad = (float)(Math.toRadians(deg));
     x = (int)((nextx)+r*Math.cos(rad));  //角度から円周上のx座標を計算
     y = (int)((nexty)+r*Math.sin(rad));  //角度から円周上のy座標を計算
     drawLine(x, y, cSize);
     if(breakCheck()){return;}
  }

  end = getStartPointX()+getHalfSizeX()+getHalfSizeX()/3;
  nextx = x;
  nexty = y;
  for(;nextx <= end ;nextx=nextx+3,nexty=nexty-(float)0.1){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  nexty = getHalfPointY()+getHalfSizeY()/2+getHalfSizeY()/8-17;
  //////////////
   deg = 270;
   r   = 40;
   x   = 0;
   y   = 0;
  for(;deg <= 360;deg++){
     float rad = (float)(Math.toRadians(deg));
     x = (int)((nextx)+r*Math.cos(rad));  //角度から円周上のx座標を計算
     y = (int)((nexty)+r*Math.sin(rad));  //角度から円周上のy座標を計算
     drawLine(x, y, cSize);
     if(breakCheck()){return;}
  }

  nexty = y;
  nextx = x;
  end   = endPointY;//getHalfPointY()+getHalfSizeY()/2;
  for(;nexty <= end ;nexty=nexty+((float)1*fontsize)){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }
}
/*--------------------------------------------------------
//void drawCharI()
//@return  なし
//@note    ひらがな「い」の書き順を描画する
--------------------------------------------------------*/
public void drawCharI()
{
  float fontsize=1;
  //フォントサイズの変更
  if(DEFAULT_SIZE > dSize){
     fontsize = dSize/DEFAULT_SIZE;
     startPointX = startPointX*fontsize;
     startPointY = startPointY*fontsize;
  }

  //--- 書き順 1-1 ---///
  float start  = getStartPointX();
  float end    = getHalfPointY() + getHalfSizeY() / 2;
  float nextx  = getStartPointX() + getHalfSizeX() /3;
  float nexty  = getStartPointY();
  for(;nexty <= end ;nexty=nexty+((float)0.8*fontsize)){
     nextx = end*0.70 > nexty ? nextx : nextx+((float)0.11*fontsize);
     nextx = end*0.80 > nexty ? nextx-((float)0.1*fontsize) : nextx;
     drawLine(nextx, nexty, cSize);
     if(breakCheck()){return;}
  }

  //--- 書き順 1-2 ---///
  start  = nexty;
  end    = getHalfPointY() + getHalfSizeY() / 4;
  nexty  = start;
  for(;nexty >= end ;nexty=nexty-(1*fontsize)){
     nextx = end*(float)0.70 > nexty ? nextx : nextx+((float)0.5*fontsize);
     drawLine(nextx, nexty, cSize);
     if(breakCheck()){return;}
  }

  //--- 書き順 1-2 ---///
  start  = getStartPointY() + getHalfSizeY() / 4;
  end    = getHalfPointY() + getHalfSizeY() / 3;
  nexty  = start;
  nextx  = getHalfPointX() + getHalfSizeX() / 2;
  for(;nexty <= end ;nexty=nexty+(1*fontsize)){
     nextx =startPointY*1.5 > nexty ? nextx+((float)0.2*fontsize) : nextx+((float)0.1*fontsize);
     drawLine(nextx, nexty, cSize);
     if(breakCheck()){return;}
  }
}

/*--------------------------------------------------------
//void drawCharU()
//@return  なし
//@note    ひらがな「う」の書き順を描画する
--------------------------------------------------------*/
public void drawCharU()
{
  float fontsize=1;
  //フォントサイズの変更
  if(DEFAULT_SIZE > dSize){
     fontsize = dSize/DEFAULT_SIZE;
     startPointX = startPointX*fontsize;
     startPointY = startPointY*fontsize;
  }

  //--- 書き順 1 ---///
  float start  = getStartPointX() + getHalfSizeX() /3;
  float end    = startPointY + getHalfSizeY()/5;
  float nextx  = start;
  float nexty  = startPointY;
  float i= 0;
  for(;nexty <= end ;nexty=nexty+((float)0.2*fontsize),nextx=nextx+(1*fontsize)){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  //--- 書き順 2-1 ---///
  start  = getStartPointX() + getHalfSizeX() /3;
  end    = getHalfPointX() + getHalfSizeX() /2;
  nextx  = start;
  nexty  = getStartPointY() + getHalfSizeY() /2;
  for(;nextx <= end ;nextx=nextx+(1*fontsize)){
    nexty = getHalfPointX() + + getHalfSizeX() / 3   > nextx ? nexty: nexty+(i=i+((float)0.1*fontsize));
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  //--- 書き順 2-1 ---///
  start  = nexty;
  end    = endPointY;
  nexty  = start;
   i= 0;
  for(;nexty <= end ;nexty=nexty+(1*fontsize)){
    nextx = getHalfPointY()+getHalfSizeY()/2 > nexty ? nextx+(float)0.01 : nextx-(i=i+((float)0.05*fontsize));
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

}

/*--------------------------------------------------------
//void drawCharE()
//@return  なし
//@note    ひらがな「え」の書き順を描画する
--------------------------------------------------------*/
public void drawCharE()
{

  float fontsize=1;
  //フォントサイズの変更
  if(DEFAULT_SIZE > dSize){
     fontsize = dSize/DEFAULT_SIZE;
     startPointX = startPointX*fontsize;
     startPointY = startPointY*fontsize;
  }

  //--- 書き順 1 ---///
  float start  = getHalfPointX() - getHalfSizeX( )/ 2 ;
  float end    = startPointY + getHalfSizeY()/5;
  float nextx  = start;
  float nexty  = startPointY;
  for(;nexty <= end ;nexty=nexty+((float)0.2*fontsize),nextx=nextx+(1*fontsize)){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  //--- 書き順 2-1 ---///
  //start  = startPointX*(float)0.7;
  end    = getHalfPointX()  + getHalfSizeX() / 2;
  nexty  = getStartPointY() + getHalfSizeY() / 2;
  nextx  = start;
  for(;nextx <= end ;nextx=nextx+(1*fontsize)){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  //--- 書き順 2-2 ---///
  start  = nexty;
  end    = getHalfPointY()+getHalfSizeY()/2+getHalfSizeY()/4;
  for(;nexty <= end ;nexty=nexty+(1*fontsize),nextx=nextx-(1*fontsize)){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  //--- 書き順 3 ---///
  nexty  = getHalfPointY();
  start  = getHalfPointX();
  end    = getHalfPointX()+getHalfSizeX()/2;
  nextx  = start;

  for(;nextx <= end ;nextx=nextx+(1*fontsize)){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  end    = getHalfPointY()+getHalfSizeY()/2+getHalfSizeY()/4;
  for(;nexty <= end ;nexty=nexty+(1*fontsize)){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  end    = endPointX;
  for(;nextx <= end ;nextx=nextx+(1*fontsize)){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

}
/*--------------------------------------------------------
//void drawCharA()
//@return  なし
//@note    ひらがな「お」の書き順を描画する
--------------------------------------------------------*/
public void drawCharO()
{

  float fontsize=1;
  //フォントサイズの変更
  if(DEFAULT_SIZE > dSize){
     fontsize = dSize/DEFAULT_SIZE;
     startPointX = startPointX*fontsize;
     startPointY = startPointY*fontsize;
  }

  //--- 書き順 1 ---//
  float start  = getHalfPointY()+getHalfSizeY()/2+getHalfSizeY()/4;
  float end    = getHalfPointX();
  float nextx  = getHalfPointX()-getHalfSizeX()/2-getHalfSizeX()/4;
  float nexty  = getHalfPointY()-getHalfSizeY()/2;//2-getHalfSizeY()/4;

  for(;nextx <= end ;nextx=nextx+3,nexty=nexty-(float)0.1){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  //--- 書き順 2 ---///
  //start  = getHalfPointX()-getHalfSizeX()/2;
  end    = endPointY;
  nextx  = getHalfPointX()-getHalfSizeX()/2;
  nexty  = getHalfPointY()-getHalfSizeY()/2-getHalfSizeY()/4;
  for(float i=0 ;nexty <= end ;nexty=nexty+3){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  //--- 書き順 2-1 ---//
  //　半円を描く //
  nextx = getHalfPointX()-getHalfSizeX()/2;
  nexty = getHalfPointY()+getHalfSizeY()/2+getHalfSizeY()/8;
  int deg = 90;
  int r   = 40;
  int x   = 0;
  int y   = 0;
  for(;deg <= 270;deg++){
     float rad = (float)(Math.toRadians(deg));
     x = (int)((nextx)+r*Math.cos(rad));  //角度から円周上のx座標を計算
     y = (int)((nexty)+r*Math.sin(rad));  //角度から円周上のy座標を計算
     drawLine(x, y, cSize);
     if(breakCheck()){return;}
  }

  //--- 書き順 2-2 ---//
  nextx  = getHalfPointX()-getHalfSizeX()/2;
  nexty  = y;
  end    = getHalfPointX();
  for(;nextx <= end ;nextx=nextx+3,nexty=nexty-(float)0.1){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  //--- 書き順 2-3 ---//
  nexty = getHalfPointY()+getHalfSizeY()/2+getHalfSizeY()/8;
   deg = 270;
   r   = 40;
   x   = 0;
   y   = 0;
  for(;deg <= 450;deg++){
     float rad = (float)(Math.toRadians(deg));
     x = (int)((nextx)+r*Math.cos(rad));  //角度から円周上のx座標を計算
     y = (int)((nexty)+r*Math.sin(rad));  //角度から円周上のy座標を計算
     drawLine(x, y, cSize);
     if(breakCheck()){return;}
  }

  nexty = getHalfPointY()-getHalfSizeY()/2;
  nextx = getHalfPointX()+getHalfSizeX()/2;
  end   = getHalfPointX()+getHalfSizeX()/2+getHalfSizeX()/4;
  for(;nextx <= end ;nexty=nexty+((float)0.75*fontsize),nextx=nextx+(1*fontsize)){
    drawLine(nextx, nexty, cSize);
    if (breakCheck()) {return;}
  }
}

}

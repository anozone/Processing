package jp.ad.SOPaint.Android;

import processing.core.PApplet;
/** ---------------------------------------
 * ま行描画クラス
 * @author YM 2012/06/18-20
 *-----------------------------------------*/
class DrawMALine extends DrawChar {


/** ---------------------------------------
   * DrawMALine(float, float, float, float)
   * コンストラクタ
   * @author YM 2012/06/18
   * @param x 描画開始位置座標X
   * @param y 描画開始位置座標Y
   * @param d 描画する大きさ
   * @param c 線の太さ
   *-----------------------------------------*/
  public DrawMALine (float x, float y, float d, float c, ThreadHandle th, PApplet pa)
  {
	super(th, pa);
    startPointX = x;
    startPointY = y;
    dSize = d;
    cSize = c;
    endPointX = startPointX + dSize;              //例 100 + 100 = 200
    endPointY = startPointY + dSize;
    halfSizeX = (endPointX - startPointX) / 2;    // (200 - 100) / 2 = 50
    halfSizeY = (endPointY - startPointY) / 2;
    halfPointX = startPointX + halfSizeX;         // 100 + 50 = 150
    halfPointY = startPointY + halfSizeY;
  }

  /** ---------------------------------------
   * void drawCharMA()
   * ひらがな「ま」の書き順を描画する
   * @author YM 2012/06/18
   * @return なし
   *-----------------------------------------*/
  public void drawCharMA()
  {
    float startx = getStartPointX() + (getHalfSizeX() / 4);
    float starty = getStartPointY() + (getHalfSizeY() / 4);
    float endx = getEndPointX() - (getHalfSizeX() / 4);
    float endy = 0;
    float counter = 3;
    float lx = 0;
    float ly = 0;

    try {
      //書き順1
      for (; startx < endx; startx=startx+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) { return; }
      }
      //書き順2
      startx = getStartPointX() + (getHalfSizeX() / 3);
      starty = getHalfPointY() - (getHalfSizeY() / 4);
      endx = getEndPointX() - (getHalfSizeX() / 3);
      for (; startx < endx;  startx=startx+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) {   return;  }
      }

      //書き順3
      startx = getHalfPointX();
      starty = getStartPointY();
      endy = getEndPointY() - (getHalfSizeY() / 2);
      for (; starty < endy; starty=starty+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) {   return;  }
      }

      //書き順3-2
      endy = getEndPointY();
      lx = 0;
      ly = 0;
      float xcntr = 0;
      float cshy = starty;      //折り返し地点Y（下に振り下ろすポイント
      float cshx = startx + 1;  //折り返し制御（Xが現在地含む左側にいる場合
      for (; starty < endy; starty=starty+counter-ly, startx=startx-xcntr + lx) {
        drawLine(startx, starty, cSize);
        //よの、○部分を構成：xの微調整
        if(xcntr < counter+1.5) xcntr = xcntr + (float)0.5;
        lx = lx + (float)0.1;
        //よの、○部分を構成：振り下ろすタイミング調整
        if(starty >= cshy && startx <= cshx ) ly = ly + (float)0.1;  //○の上部にくるまでは減速
        else ly = ly - (float)0.2;                                   //○上部にきたため、振り下ろし
        if (breakCheck()) {   return;  }
      }
   } catch (ArrayIndexOutOfBoundsException e) {
     println("OutOfBoundsError");
     e.printStackTrace();
   } catch (NullPointerException e) {
     println("NullPointerError");
     e.printStackTrace();
   } catch (OutOfMemoryError e) {
     println("OutOfMemoryError");
     e.printStackTrace();
   } catch (Exception e) {
     println("CriticalError");
     e.printStackTrace();
   }
  }

   /** ---------------------------------------
   * void drawCharMI()
   * ひらがな「み」の書き順を描画する
   * @author YM 2012/06/18
   * @return なし
   *-----------------------------------------*/
  public void drawCharMI()
  {
    float startx = getHalfPointX() - (getHalfSizeX() / 4);
    float starty = getStartPointY() + (getHalfSizeY() / 4);
    float endx = getHalfPointX() + (getHalfSizeX() / 4);
    float endy = 0;
    float counter = 3;
    float lx = 0;
    float ly = 0;

    try {
      //書き順1
      for (; startx < endx; startx=startx+counter) {
        drawLine(startx,starty, cSize);
        if (breakCheck()) { return; }
      }

      //書き順2
      endy = getEndPointY() - (getHalfSizeY() / 4);
      for(;starty < endy; startx=startx-(float)1.5, starty=starty+counter) {
        drawLine(startx, starty, cSize);
        if(breakCheck()) {return;}
      }

      //書き順2-2
      endy = getEndPointY() - (getHalfSizeY() / (float)1.5);
      for(; starty > endy; startx=startx-(float)1.5, starty=starty-counter) {
        drawLine(startx, starty, cSize);
        if(breakCheck()) {return;}
      }

      //書き順2-3
      endx = getEndPointX();

      for(; startx < endx; startx=startx+counter, starty=starty+ly) {
        drawLine(startx, starty, cSize);
        if(breakCheck()) {return;};
      }

      //書き順2-4
      startx = getEndPointX() - (getHalfSizeX() / 4);
      starty = getStartPointY() + (getHalfSizeY() / 2);
      endy = getEndPointY();
      for(; starty < endy; starty=starty+counter, startx=startx-lx) {
        drawLine(startx, starty, cSize);
        lx = lx + (float)0.01;
        if(breakCheck()) {return;}
      }
    } catch (ArrayIndexOutOfBoundsException e) {
      println("OutOfBoundsError");
      e.printStackTrace();
    } catch (NullPointerException e) {
      println("NullPointerError");
      e.printStackTrace();
    } catch (OutOfMemoryError e) {
      println("OutOfMemoryError");
      e.printStackTrace();
    } catch (Exception e) {
      println("CriticalError");
      e.printStackTrace();
    }
  }

     /** ---------------------------------------
   * void drawCharMU()
   * ひらがな「む」の書き順を描画する
   * @author YM 2012/06/18
   * @return なし
   *-----------------------------------------*/
  public void drawCharMU()
  {
    float startx = getStartPointX() + (getHalfSizeX() / 4);
    float starty = getStartPointY() + (getHalfSizeY() / 2);
    float endx = getHalfPointX() + (getHalfSizeX() / 4);
    float endy = getHalfPointY() + (getHalfSizeY() / 2);
    float counter = 3;
    float lx = 0;
    float ly = 0;

    try {
      //書き順1
      for (; startx < endx; startx=startx+counter) {
        drawLine(startx,starty, cSize);
        if (breakCheck()) { return; }
      }

      //書き順2
      startx = getHalfPointX() - (getHalfSizeX() / 4);
      starty = getStartPointY();
      for(; starty < endy; starty = starty+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) { return; }
      }

      //書き順2-2
      for(float i=0; i < 3.14*2; i=i+(float)0.1) {
        drawLine(startx, starty, cSize);
        startx=(float)Math.sin(-i)*2+startx;  //startx=開始ポイント *2 円の大きさ
        starty=(float)Math.cos(-i)*2+starty;
        if(breakCheck()){return;}
      }

      //書き順2-3
      endy = getEndPointY() - (getHalfSizeY() / 4);
      for(; starty < endy; starty=starty+counter) {
        drawLine(startx, starty, cSize);
        if(breakCheck()){return;}
      }

      //書き順2-4
      endy = getEndPointY();
      endx = getEndPointX() - (getHalfSizeX() / 4);
      ly = 1;
      lx = 0;
      for(; startx < endx; startx=startx+lx, starty=starty+ly) {
        drawLine(startx, starty, cSize);
        if(starty <= endy) {
          ly = ly + 1;
          lx = lx +(float) 0.3;
        } else {
          ly = 0;
          lx = 3;
        }
        if(breakCheck()){return;}
      }

      //書き順2-5
      endx = getEndPointX();
      endy = getHalfPointY()+ (getHalfSizeY() / 2);
      lx = 0;
      for(; starty > endy; startx=startx+2+lx, starty=starty-counter) {
        drawLine(startx, starty, cSize);
        if(starty < endx) {
          lx = lx - (float)0.1;
        } else {
          lx = 0;
        }
        if(breakCheck()){return;}
      }

      //書き順2-6
      startx = getEndPointX() - (getHalfSizeY() / 3);
      starty = getStartPointY() + (getHalfSizeY() / 2);
      endy = getHalfPointY();
      for(; starty < endy; startx=startx+1, starty=starty+counter) {
        drawLine(startx, starty, cSize);
      }
    } catch (ArrayIndexOutOfBoundsException e) {
      println("OutOfBoundsError");
      e.printStackTrace();
    } catch (NullPointerException e) {
      println("NullPointerError");
      e.printStackTrace();
    } catch (OutOfMemoryError e) {
      println("OutOfMemoryError");
      e.printStackTrace();
    } catch (Exception e) {
      println("CriticalError");
      e.printStackTrace();
    }
  }

   /** ---------------------------------------
   * void drawCharME()
   * ひらがな「め」の書き順を描画する
   * @author YM 2012/06/19
   * @return なし
   *-----------------------------------------*/
  public void drawCharME()
  {
    float startx = getStartPointX() + (getHalfSizeX() / 2);
    float starty = getStartPointY() + (getHalfSizeY() / 4);

    float endy = getEndPointY() - (getHalfSizeY() / 4);
    float counter = 3;

    float ly = 0;

    try {
      //書き順1
      for (; starty < endy;startx=startx+1,starty=starty+counter) {
        drawLine(startx,starty, cSize);
        if (breakCheck()) { return; }
      }

      //書き順2
      startx = getHalfPointX() + (getHalfSizeX() / 4);
      starty = getStartPointY();
      for(; starty < endy;startx=startx-(float)1.5, starty=starty+counter) {
        drawLine(startx, starty, cSize);
        if(breakCheck()) { return; }
      }

      //書き順2-2
      endy = getHalfPointY() + (getHalfSizeY() / 6);
      for(; starty > endy; startx=startx-1, starty=starty-counter) {
        drawLine(startx, starty, cSize);
        if(breakCheck()) { return; }
      }

      //書き順2-3
      endy = getEndPointY();
      boolean  flag = false;
      for(; starty < endy; startx=startx+counter, starty=starty-3+ly) {
        drawLine(startx, starty, cSize);
        ly = ly +(float) 0.08;
        if((startx > getEndPointX() - (getHalfSizeY() / 4) )&& !flag) {
          counter =(float) 1.5;
          flag = true;
        } else if (flag) {          //折り返し部分
           counter = counter - (float)0.1;
        }
        if(breakCheck()) { return; }
      }
    } catch (ArrayIndexOutOfBoundsException e) {
      println("OutOfBoundsError");
      e.printStackTrace();
    } catch (NullPointerException e) {
      println("NullPointerError");
      e.printStackTrace();
    } catch (OutOfMemoryError e) {
      println("OutOfMemoryError");
      e.printStackTrace();
    } catch (Exception e) {
      println("CriticalError");
      e.printStackTrace();
    }
  }

   /** ---------------------------------------
   * void drawCharMO()
   * ひらがな「も」の書き順を描画する
   * @author YM 2012/06/20
   * @return なし
   *-----------------------------------------*/
  public void drawCharMO()
  {
    float startx = getHalfPointX();
    float starty = getStartPointY();
    float endx = getEndPointX() - (getHalfSizeX() / 3);
    float endy = getEndPointY() - (getHalfSizeY() / 2);
    float counter = 3;
    float lx = 0;
    float ly = 0;

    try {

      //書き順1
      for (; starty < endy;startx=startx-(float)0.5, starty=starty+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) {   return;  }
      }

      //書き順1-2
      endy = getHalfPointY() + (getHalfSizeY() / 10);
      boolean flag = false;
      for(; starty > endy;startx=startx+lx, starty=starty+counter-ly) {
        drawLine(startx, starty, cSize);
        if(startx <= getEndPointX() - (getHalfSizeX() / 2) && !flag) {
          lx = lx + (float)0.1;
        } else if (startx > getEndPointX() - (getHalfSizeX() / 3) && !flag) {
          flag = true;      //折り返しフラグ
          lx = 1;           //微調整
        } else if (flag) {  //折り返し部分
          lx = lx - (float)0.05;
        }
        ly = ly + (float)0.1;
        if (breakCheck()) {   return;  }
      }

      //書き順2
      startx = getStartPointX() + (getHalfSizeX() / 3);
      starty =  getStartPointY() + (getHalfSizeY() / 4);
      for (; startx < endx;  startx=startx+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) {   return;  }
      }

      //書き順3
      startx = getStartPointX() + (getHalfSizeX() / 4);
      starty = getHalfPointY() - (getHalfSizeY() / 4);
      endx = getEndPointX() - (getHalfSizeX() / 4);
      for (; startx < endx; startx=startx+counter) {
        drawLine(startx, starty, cSize);
        if (breakCheck()) { return; }
      }
   } catch (ArrayIndexOutOfBoundsException e) {
     println("OutOfBoundsError");
     e.printStackTrace();
   } catch (NullPointerException e) {
     println("NullPointerError");
     e.printStackTrace();
   } catch (OutOfMemoryError e) {
     println("OutOfMemoryError");
     e.printStackTrace();
   } catch (Exception e) {
     println("CriticalError");
     e.printStackTrace();
   }
  }
  //class end
}

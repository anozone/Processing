package jp.ad.SOPaint.Android;

/** ---------------------------------------
 * スレッド情報受け渡しインターフェース
 * @author YM 2012/06/26
 *-----------------------------------------*/
public interface ThreadHandle {
	void sopSleep(int sec);
}


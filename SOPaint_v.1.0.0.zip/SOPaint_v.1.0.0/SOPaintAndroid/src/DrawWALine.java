package jp.ad.SOPaint.Android;

import processing.core.PApplet;

/** ---------------------------------------
* わ行描画クラス
* @author YM 2012/06/07-08
*-----------------------------------------*/
class DrawWALine extends DrawChar{
/**
	 *
	 */
	private static final long serialVersionUID = 1L;

/** ---------------------------------------
* DrawRALine(float, float, float, float)
* コンストラクタ
* @author YM 2012/06/08
* @param x 描画開始位置座標X
* @param y 描画開始位置座標Y
* @param d 描画する大きさ
* @param c 線の太さ
*-----------------------------------------*/
public  DrawWALine (float x, float y, float d, float c, ThreadHandle th, PApplet pa)
  {
	super(th, pa);
  startPointX = x;
  startPointY = y;
  dSize = d;
  cSize = c;
  endPointX = startPointX + dSize;              //例 100 + 100 = 200
  endPointY = startPointY + dSize;
  halfSizeX = (endPointX - startPointX) / 2;    // (200 - 100) / 2 = 50
  halfSizeY = (endPointY - startPointY) / 2;
  halfPointX = startPointX + halfSizeX;         // 100 + 50 = 150
  halfPointY = startPointY + halfSizeY;
}

/** ---------------------------------------
* void drawCharWA()
* ひらがな「わ」の書き順を描画する
* @author YM 2012/06/07
* @return なし
*-----------------------------------------*/
public void drawCharWA()
{
  float startx = getStartPointX() + (getHalfSizeX() / 2);
  float starty = getStartPointY();
  float endx = startPointX + (halfSizeX / 2);
  float endy = getEndPointY();
  float lx = 0;
  float ly = 0;
  float counter = 3;

  try {
   //書き順1
    for(;starty < endy; starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

    //書き順2
    startx = getStartPointX();
    starty = getStartPointY() + (getHalfSizeY() / 2);
    for (;startx <= endx; startx=startx+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

  //書き順3
   endy = getHalfPointY() + (getHalfSizeY() / 2);
   for(;starty < endy; startx=startx-counter+1, starty=starty+counter){
     drawLine(startx, starty, cSize);
    if(breakCheck()){return;}
   }

  //書き順4
   endx = getStartPointX() + (getHalfSizeX() / 2);
   for(;startx < endx; startx=startx+counter+(3/2), starty=starty-counter) {
     drawLine(startx, starty, cSize);
     if(breakCheck()){return;}
   }

   //書き順5
   endy = getEndPointY();
   for(;starty < endy;startx=startx+counter+(3/2)-lx, starty=starty-counter+ly) {
      drawLine(startx, starty, cSize);
      if(starty < getEndPointY() - getHalfSizeY()){ lx = lx + (float)0.025;}
      else {
        if(lx <= 6)lx = lx + (float)0.5;
      }
      if(ly <= 6)ly = ly + (float)0.15;
      if(breakCheck()){return;}
    }
  //error処理
  } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}

/** ---------------------------------------
* void drawCharWO()
* ひらがな「を」の書き順を描画する
* @author YM 2012/06/08
* @return なし
*-----------------------------------------*/
public void drawCharWO()
{
  float startx = getStartPointX() + (getHalfSizeX() / 2);
  float starty = getHalfPointY() - (getHalfSizeY() / 2);
  float endx = getEndPointX() - (getHalfSizeX() / 2);
  float endy = getHalfPointY();
  float lx = 0;
  float ly = 0;
  float counter = 3;

  //書き順1
  try {
    for(;startx < endx; startx=startx+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

    //書き順2
    startx = getHalfPointX()  ;
    starty = getStartPointY();
    for(;starty < endy; starty=starty+counter,startx=startx-1) {
       drawLine(startx, starty, cSize);
       if(breakCheck()){return;}
    }
  
    float cx = startx; // xの位置を保存
    float cy = starty; // yの位置を保存

   //書き順2-2
   endx = getHalfPointX() + (getHalfSizeX() / 10) ;
   endy = getHalfPointY() + (getHalfSizeY() / 2);
   for(;starty < endy;) {
      drawLine(startx, starty, cSize);
      if(startx < endx) {
        startx = startx + counter;
        starty = starty + ly;
        ly = ly +(float) 0.1;
      } else {
        starty = starty + counter;
      }
        if(breakCheck()){return;}
  }

  float csh = startx - cx;     //現時点とcxの距離を算出
  startx = startx - (csh / 5); //現時点から、差分の1/5の場所へ後退
  starty = cy;  //保存されたyの位置から開始

  //書き順3
  endx = getHalfPointX() + (getHalfSizeX() / 2);
  endy = getEndPointY() - (getHalfSizeY() / 10);
  for(;startx < endx;) {
     drawLine(startx, starty, cSize);
     startx = startx - counter + lx;
     if(starty < endy ) starty = starty + counter;
     lx = lx +(float) 0.1;
     if(breakCheck()){return;}
  }
 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}

/** ---------------------------------------
* void drawCharNN()
* ひらがな「ん」の書き順を描画する
* @author YM 2012/06/07-8
* @return なし
*-----------------------------------------*/
public void drawCharNN()
{
  float startx = getHalfPointX();
  float starty = getStartPointY();
  float endx = getHalfPointX();
  float endy = getEndPointY();
  float lx = 0;
  float ly = 0;
  float counter = 3;

    //書き順1
    try {
      for(;starty < endy;startx=startx-(counter/2),starty=starty+counter) {  //最後まで
        drawLine(startx, starty, cSize);
        if(breakCheck()){return;}
      }

      //書き順1-2
      endy = getHalfPointY();
      for(;starty > endy;startx=startx+counter, starty=starty-counter) {
        drawLine(startx, starty, cSize);
        if(breakCheck()){return;}
      }

      //書き順1-3
      endy = getEndPointY();
      for(;starty < endy;startx=startx-(float)0.25+lx, starty=starty+counter,lx=lx+(float)0.1) {
        drawLine(startx, starty, cSize);
        if(breakCheck()){return;}
      }

    //書き順1-4
      endx =getEndPointX();
      for(;startx < endx;startx=startx+counter,starty=starty+(float)0.5+ly,ly=ly-(float)0.25) {
        drawLine(startx,starty,cSize);
        if(breakCheck()){return;}
      }

 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}
}


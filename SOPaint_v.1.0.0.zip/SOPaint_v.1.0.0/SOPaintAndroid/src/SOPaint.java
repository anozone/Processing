package jp.ad.SOPaint.Android;

import java.util.ArrayList;
import processing.core.PApplet;
import android.os.Handler;
import android.os.HandlerThread;

/** ---------------------------------------
* 文字書き順クラス
* @author YM 2012/06/06-19
* @author R  2012/06/19
*-----------------------------------------*/
public class SOPaint implements ThreadHandle
{
private static final float DEFAULT_SIZE = 200;
public static final String JAPANESE = "JAPANESE";
public static final String ENGLISH = "ENGLISH";
  //キャンセル処理に必要なリスト
private  ArrayList <DrawChar>alist = new ArrayList<DrawChar>(); //breakFlagを保持
String type;  //日本語or英語
String name;  //文字
float x;      //描画位置
float y;
float dSize;  //大きさ
//検索用
int i = -1;
PApplet pa;
int spd = 10;


private final HandlerThread ht;
private final Handler hl;
private boolean sMem;
private boolean threadFlag;

String []searchStr = new String[] {
        "あいうえお",                //4
        "かきくけこ",                //9
        "さしすせそ",                //14
        "たちつてと",                //19
        "なにぬねの",                //24
        "はひふへほ",                //29
        "まみむめも",                //34
        "やゆよ",                    //37
        "らりるれろ",                //42
        "わをん"};                   //45

//@override
public SOPaint(float lx, float ly, String str, PApplet app)
{
  sMem = false;
  threadFlag = true;
  type = JAPANESE;   //文字タイプ
  name = str;  //文字
  x = lx;      //描画位置
  y = ly;      //描画位置
  dSize = DEFAULT_SIZE;
  pa = app;
  ht = new HandlerThread("sop");
  ht.start();
  hl = new Handler(ht.getLooper());
}

/*  StrokeOrder(float lx, float ly, String chr, String st)
{
  type = st;   //文字タイプ
  name = chr;  //文字
  x = lx;      //描画位置
  y = ly;      //描画位置
  dSize = DEFAULT_SIZE;
}*/
/*StrokeOrder(float lx, float ly, String chr, float sSize)
{
  type = JAPANESE;   //文字タイプ
  name = chr;  //文字
  x = lx;      //描画位置
  y = ly;      //描画位置
  dSize = sSize;

}*/

/** ---------------------------------------
* void sopStart()
* Thread描画開始
* @author YM 2012/07/04
* @return なし
*-----------------------------------------*/
public void sopStart()
{
	hl.post(new Runnable() {
		public void run() {
			try{
				if(type.indexOf(JAPANESE) != -1 ) {
					if(sMem)println("Input set String drawing...");
				    drawJapanese();
				} else if(type.indexOf(ENGLISH) != -1) {
					// drawEnglish();
				} else {
					if(sMem)println("LanguageError");
				  //  exit();
				}
				if(sMem)println("finish");
				threadFlag = false;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	});

}

/** ---------------------------------------
* void drawJapanese
* 対応する日本語の書き順を描画する。
* @author YM 2012/06/06-20
* @author KR 2012/06/19
* @return なし
*-----------------------------------------*/
private void drawJapanese() {
  float circleSize = 10;

 if(dSize < DEFAULT_SIZE) {
   circleSize = 5;
 } else if(dSize > DEFAULT_SIZE) {
   circleSize = 15;
 }
 try {
     //あ
     if((i = searchStr[0].indexOf(name)) != -1){
        DrawALine d = new DrawALine(x, y, dSize, circleSize,this,pa);   //位置,文字の大きさ,描画タイプ,点の大きさ
        d.setSleepSec(spd);
        alist.add(d);

        switch(i){
          case 0:d.drawCharA();break;
          case 1:d.drawCharI();break;
          case 2:d.drawCharU();break;
          case 3:d.drawCharE();break;
          case 4:d.drawCharO();break;
        }
        alist.clear();

      //か
      } else if((i = searchStr[1].indexOf(name)) != -1){
        DrawKALine d = new DrawKALine(x, y, dSize, circleSize,this,pa);
        d.setSleepSec(spd);
        alist.add(d);

        switch(i){
          case 0:d.drawCharKA();break;
          case 1:d.drawCharKI();break;
          case 2:d.drawCharKU();break;
          case 3:d.drawCharKE();break;
          case 4:d.drawCharKO();break;
        }
        alist.clear();
      //さ
      } else if((i = searchStr[2].indexOf(name)) != -1){
        DrawSALine d = new DrawSALine(x, y, dSize, circleSize,this,pa);
        d.setSleepSec(spd);
        alist.add(d);

        switch(i){
          case 0:d.drawCharSA();break;
          case 1:d.drawCharSI();break;
          case 2:d.drawCharSU();break;
          case 3:d.drawCharSE();break;
          case 4:d.drawCharSO();break;
        }
        alist.clear();
      //た
      } else if((i = searchStr[3].indexOf(name)) != -1){
        DrawTALine d = new DrawTALine(x, y, dSize, circleSize,this,pa);
        d.setSleepSec(spd);
        alist.add(d);

        switch(i){
          case 0:d.drawCharTA();break;
          case 1:d.drawCharTI();break;
          case 2:d.drawCharTU();break;
          case 3:d.drawCharTE();break;
          case 4:d.drawCharTO();break;
        }
        alist.clear();
      //な
      } else if((i = searchStr[4].indexOf(name)) != -1){
        DrawNALine d = new DrawNALine(x, y, dSize, circleSize,this,pa);
        d.setSleepSec(spd);
        alist.add(d);

        switch(i){
          case 0:d.drawCharNA();break;
          case 1:d.drawCharNI();break;
          case 2:d.drawCharNU();break;
          case 3:d.drawCharNE();break;
          case 4:d.drawCharNO();break;
        }
        alist.clear();
      //は
      } else if((i = searchStr[5].indexOf(name)) != -1){
        DrawHALine d = new DrawHALine(x, y, dSize, circleSize,this,pa);
        d.setSleepSec(spd);
        alist.add(d);

        switch(i){
          case 0:d.drawCharHA();break;
          case 1:d.drawCharHI();break;
          case 2:d.drawCharHU();break;
          case 3:d.drawCharHE();break;
          case 4:d.drawCharHO();break;
        }
        alist.clear();
      //ま
      } else if((i = searchStr[6].indexOf(name)) != -1){
        DrawMALine d = new DrawMALine(x, y, dSize, circleSize,this,pa);
        d.setSleepSec(spd);
        alist.add(d);

        switch(i){
          case 0:d.drawCharMA();break;
          case 1:d.drawCharMI();break;
          case 2:d.drawCharMU();break;
          case 3:d.drawCharME();break;
          case 4:d.drawCharMO();break;
        }
        alist.clear();
      //や
      } else if((i = searchStr[7].indexOf(name)) != -1){
        DrawYALine d = new DrawYALine(x, y, dSize, circleSize,this,pa);
        d.setSleepSec(spd);
        alist.add(d);

        switch(i){
          case 0:d.drawCharYA();break;
          case 1:d.drawCharYU();break;
          case 2:d.drawCharYO();break;
        }
        alist.clear();
      //ら
      } else if((i = searchStr[8].indexOf(name)) != -1){
        DrawRALine d = new DrawRALine(x, y, dSize, circleSize, this,pa);
        d.setSleepSec(spd);
        alist.add(d);

        switch(i){
          case 0:d.drawCharRA();break;
          case 1:d.drawCharRI();break;
          case 2:d.drawCharRU();break;
          case 3:d.drawCharRE();break;
          case 4:d.drawCharRO();break;
        }
        alist.clear();
      //わ
      } else if((i = searchStr[9].indexOf(name)) != -1){
        DrawWALine d = new DrawWALine(x, y, dSize, circleSize,this,pa);
        d.setSleepSec(spd);
        alist.add(d);

        switch(i){
          case 0:d.drawCharWA();break;
          case 1:d.drawCharWO();break;
          case 2:d.drawCharNN();break;
        }
        alist.clear();
      } else {
        throw new IllegalArgumentException("Please specify the hiragana.");
      }
 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError22");
   e.printStackTrace();
 }
}

/** ---------------------------------------
* void sopCancel()
* 実行中の描画をcancelする
* @author YM 2012/06/06
* @return なし
*-----------------------------------------*/
public synchronized void sopCancel()
{

	if(threadFlag) {
		//Threadが稼働中の場合
		if(sMem)println("To cancel a running thread.");
	    if(alist.size() != 0) {
	      DrawChar d = (DrawChar)alist.get(0);
	      d.setBreakCheck(true);
	    }
	}
}


/** ---------------------------------------
* void sopSleep(int sec)
* 実行中の描画速度を遅延させる
* @author YM 2012/06/06
* @param sec 遅延ミリ秒
* @return なし
*-----------------------------------------*/
public void sopSleep(int sec)
{
 try {
   Thread.sleep(sec);     //sec秒待機
 } catch(InterruptedException e) {
   e.printStackTrace();
   throw new RuntimeException(e);
 }
}

/**-----------------------------------------
* private void println(Strint str)
* コンソールにメッセージを表示させる
* @param str 表示する文字列
*/
private void println(String str) {
	  System.out.println(str);
}

/**---------------------------------------
* pulic void setSopSpeed(int s)
* 文字描画の速度を設定する
* @author YM 2012/06/29
* @return なし
*/
public void setSopSpeed(int s)
{
  spd = s;
}

/**----------------------------------------
 * public void setSysMem(boolean sm)
 * システムメッセージ表示有無
 * @author YM
 * @param sm
 * @return なし
 */
public void setSysMem(boolean sm)
{
	sMem = sm;
}

}

package jp.ad.SOPaint.Android;

import processing.core.PApplet;


//--------------------------------------------------------
//「か行」描画クラス
//--------------------------------------------------------
class DrawKALine extends DrawChar{

// コンストラクタ
public DrawKALine (float x, float y, float d, float c, ThreadHandle th, PApplet pa)
{
	super(th, pa);
  startPointX = x;
  startPointY = y;
  endPointX = startPointX + d;              //例 100 + 100 = 200
  endPointY = startPointY + d;
  halfSizeX = (endPointX - startPointX) / 2;    // (200 - 100) / 2 = 50
  halfSizeY = (endPointY - startPointY) / 2;
  halfPointX = startPointX + halfSizeX;         // 100 + 50 = 150
  halfPointY = startPointY + halfSizeY;
  dSize = d;
  cSize = c;
}

/*--------------------------------------------------------
// void drawCharKA()
// @return  なし
// @note    ひらがな「か」の書き順を描画する
--------------------------------------------------------*/
public void drawCharKA()
{
    //--- 書き順 1 ---//
    float start  = getStartPointX();
    float endx   = getHalfPointX();
    float nextx  = start;
    float nexty  = getHalfPointY() - getHalfSizeY()/2;
    float carve  = 0;
    float carve2  = 0;
    for(;nextx <= endx ;nextx++){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 1-2 ---//
    float endy   = getEndPointY();
    for(;nexty <= endy ;nexty++,nextx=nextx+(carve=carve-(float)0.0025)){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 2 ---//
    nextx = getHalfPointX() - getHalfSizeX()/2;
    nexty = getStartPointY();
    endx  = getStartPointX();
    for(;nextx >= endx ;nexty++,nextx=nextx-(float)0.35){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //--- 書き順 2 ---//
    nextx = getHalfPointX() + getHalfSizeX()/2;
    nexty = getStartPointY();
    endx  = getEndPointX();
    for(;nextx <= endx ;nexty++,nextx=nextx+(float)0.35){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }


 }
/*--------------------------------------------------------
// void drawCharKI()
// @return  なし
// @note    ひらがな「き」の書き順を描画する
--------------------------------------------------------*/
public void drawCharKI()
{
    //--- 書き順 1 ---//
    float start  = getHalfPointX()-getHalfSizeX()/3;
    float endx   = getHalfPointX()+getHalfSizeX()/2;
    float endy   = startPointY*2;
    float nextx  = start;
    float nexty  = getHalfPointY()-getHalfSizeY()/2;
    float carve  = 0;
    float carve2  = 0;
    for(;nextx <= endx;nextx=nextx+3,nexty=nexty-(float)0.2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 2 ---//
    nexty  = getHalfPointY();
    nextx  = getHalfPointX()-getHalfSizeX()/3;
    endx   = getHalfPointX()+getHalfSizeX()/2;
    for(;nextx <= endx;nextx=nextx+3,nexty=nexty-(float)0.2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 3 ---//
    nexty  = getStartPointY();
    nextx  = getHalfPointX();
    endy   = getHalfPointY()+getHalfSizeY()/2;
    for(;nexty <= endy;nexty=nexty+3,nextx=nextx+(float)0.5){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 4 ---//
    nexty  = getHalfPointY() + getHalfSizeY()/2;
    nextx  = getHalfPointX() - getHalfSizeX() / 2;
    endy   = getEndPointY();
    carve = 0;
    for(;nexty <= endy;nexty=nexty+3,nextx=nextx+(carve=carve+(float)0.5)){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }
}
/*--------------------------------------------------------
// void drawCharKU()
// @return  なし
// @note    ひらがな「く」の書き順を描画する
--------------------------------------------------------*/
public void drawCharKU()
{
    //--- 書き順 1 ---//
    float start  = getHalfPointX();
    float endx   = getHalfPointX()-getHalfSizeX()/2;
    float endy   = getHalfPointY();
    float nextx  = start;
    float nexty  = startPointY;
    for(;nexty <= endy;nextx=nextx-(float)1.5,nexty=nexty+2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }
    endy = getEndPointY();
    for(;nexty <= endy;nextx=nextx+(float)1.5,nexty=nexty+2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }
}
/*--------------------------------------------------------
// void drawCharKU()
// @return  なし
// @note    ひらがな「け」の書き順を描画する
--------------------------------------------------------*/
public void drawCharKE()
{
    float fontsize=1;
    //フォントサイズの変更
    if(DEFAULT_SIZE > dSize){
       fontsize = dSize/DEFAULT_SIZE;
       startPointX = startPointX*fontsize;
       startPointY = startPointY*fontsize;
    }
    //--- 書き順 1 ---///
    float start  = getHalfPointX()-getHalfSizeX()/2;
    float end    = getEndPointY();
    float nextx  = start;
    float nexty  = startPointY;
    for(;nexty <= end ;nexty=nexty+((float)0.8*fontsize)){
       nextx = getHalfPointY() > nexty ? nextx : nextx+(float)(0.11*fontsize);
       nextx = getHalfPointY()-getHalfSizeY()/2 > nexty ? nextx-((float)0.1*fontsize) : nextx;
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //--- 書き順 2 ---///
    start  = getHalfPointX();
    end    = getEndPointX();
    nextx  = start;
    nexty  = getHalfPointY()-getHalfSizeY()/2;
    for(;nextx <= end ;nextx=nextx+(2*fontsize)){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //--- 書き順 3 ---///
    start  = getHalfPointX()+getHalfSizeX()/2;
    end    = getEndPointY();
    nextx  = start;
    nexty  = startPointY;
    for(;nexty <= end ;nexty=nexty+(2*fontsize)){
       nextx = end*(float)0.70 > nexty ? nextx : nextx-((float)0.1*fontsize);
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }
}
/*--------------------------------------------------------
// void drawCharKU()
// @return  なし
// @note    ひらがな「け」の書き順を描画する
--------------------------------------------------------*/
public void drawCharKO()
{
    float fontsize=1;
    //フォントサイズの変更
    if(DEFAULT_SIZE > dSize){
       fontsize = dSize/DEFAULT_SIZE;
       startPointX = startPointX*fontsize;
       startPointY = startPointY*fontsize;
    }

    //--- 書き順 1-1 ---//
    float start  = getHalfPointX() - (getHalfSizeX() / 3) * 2;
    float end    = getHalfPointX();
    float nextx  = start;
    float nexty  = getHalfPointY() - getHalfSizeY() / 2 ;
    float carve  = 0;
    for(;nextx <= end ;nexty=nexty-(float)0.5,nextx=nextx+(carve=carve+(float)0.1)){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //--- 書き順 1-2 ---//
    end    = getHalfPointY() - getHalfSizeY() / 2 ;
    carve  = 0;
    for(;nexty <= end ;nextx=nextx+(float)1,nexty=nexty+(carve=carve+(float)0.01)){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //--- 書き順 2 ---//
    start  = getHalfPointX() - (getHalfSizeX() / 3) * 2;
    end    = getHalfPointX();
    nextx  = start;
    nexty  = getHalfPointY() + getHalfSizeY() / 2 ;
    carve  = 0;
    for(;nextx <= end ;nexty=nexty+(float)0.5,nextx=nextx+(carve=carve+(float)0.1)){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //--- 書き順 2-1 ---//
    end    = getHalfPointY() + getHalfSizeY() / 2 ;
    carve  = 0;
    for(;nexty >= end ;nextx=nextx+(float)1,nexty=nexty-(carve=carve+(float)0.01)){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

}
}

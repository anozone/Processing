package jp.ad.SOPaint.Win;

import processing.core.PApplet;


/** ---------------------------------------
* ら行描画クラス
* @author YM 2012/06/12-13
*-----------------------------------------*/
class DrawRALine extends DrawChar{

/** ---------------------------------------
* DrawRALine(float, float, float, float)
* コンストラクタ
* @author YM 2012/06/12
* @param x 描画開始位置座標X
* @param y 描画開始位置座標Y
* @param d 描画する大きさ
* @param c 線の太さ
*-----------------------------------------*/
public DrawRALine (float x, float y, float d, float c, ThreadHandle th, PApplet pa)
  {
	super(th, pa);
  startPointX = x;
  startPointY = y;
  dSize = d;
  cSize = c;
  endPointX = startPointX + dSize;              //例 100 + 100 = 200
  endPointY = startPointY + dSize;
  halfSizeX = (endPointX - startPointX) / 2;    // (200 - 100) / 2 = 50
  halfSizeY = (endPointY - startPointY) / 2;
  halfPointX = startPointX + halfSizeX;         // 100 + 50 = 150
  halfPointY = startPointY + halfSizeY;
}

 /** ---------------------------------------
* void drawCharRA()
* ひらがな「ら」の書き順を描画する
* @author YM 2012/06/12
* @return なし
*-----------------------------------------*/
public void drawCharRA()
{
  float startx = getHalfPointX();
  float starty = getStartPointY();
  float endx = getHalfPointX() + (getHalfSizeX() / 2);
  float endy = getHalfPointY() + (getHalfSizeY() / 2);
  float counter = 3;
  float lx = 0;
  float ly = 5;

  //書き順1
  try {
    for(; startx < endx; startx=startx+counter, starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

  //書き順2
    startx = getHalfPointX() - (getHalfSizeX() / 2);
    for(; starty < endy; starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

  //書き順2-2
     endx =getHalfPointX()-(getHalfSizeX()/2);
     for(;startx >= endx;startx=startx+counter-lx,starty=starty+counter-ly) {
      drawLine(startx, starty, cSize);
      if(startx >= getHalfPointX() + (getHalfSizeX() / 2)) {
        lx = lx +(float) 0.2;
      }
      if(starty < getEndPointY()) {
        ly = ly -(float) 0.1;
      } else if (starty >= getEndPointY()){
        ly = ly +(float) 0.2;
        if(ly >= counter) {
          ly = counter;
        }
      }
    if(breakCheck()){return;}
    }
 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}

/** ---------------------------------------
* void drawCharRI()
* ひらがな「れ」の書き順を描画する
* @author YM 2012/06/12
* @return なし
*-----------------------------------------*/
public void drawCharRI()
{
  float startx = halfPointX - (halfSizeX /2);
  float starty = startPointY;
  float endy = halfPointY;
  float counter = 3;
  float lx = 0;

  //書き順1
  try {
    for(; starty < endy; starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

  //書き順1-2
    for(; starty > endy - (halfSizeY /4); startx=startx+2,starty=starty-counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

  //書き順2
    for(startx = halfPointX + (halfSizeX / 2), starty = startPointY; starty < endPointY;startx=startx-lx, starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if(starty > endy)lx = lx +(float) 0.1;
      if(breakCheck()){return;}
    }
  } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}

/** ---------------------------------------
* void drawCharRU()
* ひらがな「る」の書き順を描画する
* @author YM 2012/06/12
* @return なし
*-----------------------------------------*/
public void drawCharRU()
{
  float startx = halfPointX - (halfSizeX /2);
  float starty = startPointY;
  float endx = halfPointX + (halfSizeX / 2);
  float endy = halfPointY + (halfSizeY / 2);
  float counter = 3;
  float lx = 0;
  float ly = 5;

  //書き順1
  try {
    for(; startx < endx; startx=startx+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

    //書き順1-2
    for(; starty < endy; startx=startx-counter, starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

    //書き順1-3
    for(endy = endy - ((starty - startPointY) / 4); starty > endy; startx=startx+counter+1, starty=starty-counter) {
      drawLine(startx,starty,cSize);
      if(breakCheck()){return;}
    }

    float csh = startx;    //○折り返しポイントx
    boolean flag = false;  //折り返し時に終了させないためのFlag管理
    //書き順1-4
    for(;startx >= csh ;startx=startx+counter-lx,starty=starty+counter-ly) {
      drawLine(startx, starty, cSize);
      //折り返しからこちらで計算 →から←へ
      if(startx >= endx || flag == true) {
        lx = lx + (float)0.2;
        flag = true;
      }
      //上り
      if(starty < endPointY) {
        ly = ly - (float)0.1;
      } else if(flag == true) { //折り返し時は下り
        ly = ly +(float) 0.5;
      }
      if(breakCheck()){return;}
    }

   csh = startx;          //○折り返しxポイントを保存
   float cshy = starty;   //○折り返しyポイントを保存
   lx = 0;                //微調整変数を初期化
    //折り返した位置が、記憶したYポイントを超えた場合かつ、xが記憶したポイントよりも移動していた場合
   for(; starty <= cshy || startx <= csh; startx=startx+counter-lx,starty=starty+counter-ly){
      drawLine(startx,starty,cSize);
      lx = lx -(float)  0.5;
      ly = ly -(float)  0.5;
      if(breakCheck()){return;}
   }
 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}

/** ---------------------------------------
* void drawCharRE()
* ひらがな「れ」の書き順を描画する
* @author YM 2012/06/13
* @return なし
*-----------------------------------------*/
public void drawCharRE()
{
  float startx = getStartPointX();
  float starty = getStartPointY();
  float ly = 0;
  float counter = 3;
  float nextx = startPointX + (halfSizeX / 2);
  float nexty = startPointY + (halfSizeY / 2);

  try {
    //書き順1
    for(;starty < endPointY; starty = starty+3) {
      drawLine(nextx, starty, cSize);
      if(breakCheck()){return;}
    }

   //書き順2
    for (;startx <= nextx; startx = startx+counter) {
      drawLine(startx, nexty, cSize);
      if(breakCheck()){return;}
    }

   //書き順2-2
   starty = nexty;
   nexty = halfPointY + (halfSizeY / 2);
   for(;starty < nexty; startx = startx-counter+1, starty = starty+counter){
     drawLine(startx, starty, cSize);
    if(breakCheck()){return;}
   }

   //書き順2-3
   nexty = (startPointY + (halfSizeY / 2)) - (((startPointY + (halfSizeY / 2)) - getStartPointY()) / 2);
   for(;starty >= nexty; startx = startx+counter+(3/2), starty = starty-counter) {
     drawLine(startx, starty, cSize);
     if(breakCheck()){return;}
   }

   //書き順2-4
   nexty = halfPointY + (halfSizeY / 2);
   for(;starty < nexty; starty = starty+counter) {
     drawLine(startx, starty, cSize);
     if(breakCheck()){return;}
   }

   //書き順2-5
   nextx = startx + 1;  //xの場所が右へ少しでもずれていること
   ly = 0;              //微調整
   for(;starty >= nexty || startx < nextx; starty = starty + counter - ly,startx = startx + 1) {
     drawLine(startx, starty, cSize);
     ly = ly + (float)0.1;
     if(breakCheck()){return;}
   }
 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}
/** ---------------------------------------
* void drawCharRO()
* ひらがな「る」の書き順を描画する
* @author YM 2012/06/14
* @return なし
*-----------------------------------------*/
public void drawCharRO()
{
  float startx = halfPointX - (halfSizeX /2);
  float starty = startPointY;
  float endx = halfPointX + (halfSizeX / 2);
  float endy = halfPointY + (halfSizeY / 2);
  float counter = 3;
  float lx = 0;
  float ly = 5;

  //書き順1
  try {
    for(; startx < endx; startx=startx+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

    //書き順1-2
    for(; starty < endy; startx=startx-counter, starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

    //書き順1-3
    for(endy = endy - ((starty - startPointY) / 4); starty > endy; startx=startx+counter+1, starty=starty-counter) {
      drawLine(startx,starty,cSize);
      if(breakCheck()){return;}
    }

    //書き順1-4
    float csh = startx;    //○折り返しポイントx
    boolean flag = false;  //折り返し時に終了させないためのFlag管理
    for(;startx >= csh ;startx=startx+counter-lx,starty=starty+counter-ly) {
      drawLine(startx, starty, cSize);
      //折り返しからこちらで計算 →から←へ
      if(startx >= endx || flag == true) {
        lx = lx + (float)0.2;
        flag = true;
      }
      //上り
      if(starty < endPointY) {
        ly = ly -(float) 0.1;
      } else if(flag == true) { //折り返し時は下り
        ly = ly +(float) 0.5;
      }
      if(breakCheck()){return;}
    }

 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}
//class end
}

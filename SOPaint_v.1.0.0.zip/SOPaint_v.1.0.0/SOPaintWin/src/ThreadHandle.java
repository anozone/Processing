package jp.ad.SOPaint.Win;

/** ---------------------------------------
 * スレッド情報受け渡しインターフェース
 * @author YM 2012/06/26
 *-----------------------------------------*/
public interface ThreadHandle {
	void sopSleep(int sec);
}


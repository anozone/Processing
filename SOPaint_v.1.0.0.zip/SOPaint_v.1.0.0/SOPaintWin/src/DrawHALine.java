package jp.ad.SOPaint.Win;

import processing.core.PApplet;

/** ---------------------------------------
* は行描画クラス
* @author YM 2012/06/21-22
*-----------------------------------------*/
class DrawHALine extends DrawChar{
/** ---------------------------------------
* DrawHALine(float, float, float, float)
* コンストラクタ
* @author YM 2012/06/21
* @param x 描画開始位置座標X
* @param y 描画開始位置座標Y
* @param d 描画する大きさ
* @param c 線の太さ
*-----------------------------------------*/
public DrawHALine (float x, float y, float d, float c, ThreadHandle th, PApplet pa)
  {
	super(th, pa);
  startPointX = x;
  startPointY = y;
  dSize = d;
  cSize = c;
  endPointX = startPointX + dSize;              //例 100 + 100 = 200
  endPointY = startPointY + dSize;
  halfSizeX = (endPointX - startPointX) / 2;    // (200 - 100) / 2 = 50
  halfSizeY = (endPointY - startPointY) / 2;
  halfPointX = startPointX + halfSizeX;         // 100 + 50 = 150
  halfPointY = startPointY + halfSizeY;
}

/** ---------------------------------------
* void drawCharHA()
* ひらがな「は」の書き順を描画する
* @author YM 2012/06/21
* @return なし
*-----------------------------------------*/
public void drawCharHA()
{
  float startx = getStartPointX();
  float starty = getStartPointY();
  float endx = getEndPointX() - (getHalfSizeX() / 3);
  float endy = getEndPointY();
  float counter = 3;
  float lx = 0;
  float ly = 0;

  try {
    //書き順1
    for (; starty < endy; starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) {return;}
    }

    //書き順2
    startx = getStartPointX() + (getHalfSizeX() / 2);
    starty = getStartPointY() + (getHalfSizeY() / 2);
    endx = getEndPointX() - (getHalfSizeX() / 4);
    for (; startx < endx; startx=startx+counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) { return; }
    }

    //書き順3
    startx = getHalfPointX() + (getHalfSizeX() / 4);
    starty = getStartPointY();
    endy = getEndPointY() - (getHalfSizeY() / 2);
    for (; starty < endy; starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) {   return;  }
    }

    //書き順3-2
    endy = getEndPointY();
    lx = 0;
    ly = 0;
    float xcntr = 0;
    float cshy = starty;      //折り返し地点Y（下に振り下ろすポイント
    float cshx = startx + 1;  //折り返し制御（Xが現在地含む左側にいる場合
    for (; starty < endy; starty=starty+counter-ly, startx=startx-xcntr + lx) {
      drawLine(startx, starty, cSize);
      //よの、○部分を構成：xの微調整
      if(xcntr < counter+1.5) xcntr = xcntr + (float)0.5;
      lx = lx + (float)0.1;
      //よの、○部分を構成：振り下ろすタイミング調整
      if(starty >= cshy && startx <= cshx ) ly = ly + (float)0.1;  //○の上部にくるまでは減速
      else ly = ly - (float)0.2;                                   //○上部にきたため、振り下ろし
      if (breakCheck()) {   return;  }
    }
 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}

/** ---------------------------------------
* void drawCharHI()
* ひらがな「ひ」の書き順を描画する
* @author YM 2012/06/21
* @return なし
*-----------------------------------------*/
public void drawCharHI()
{
  float startx = getStartPointX() + (getHalfSizeX() / 2);
  float starty = getStartPointY() + (getHalfSizeX() / 5);
  float endx = getStartPointX() + (getHalfSizeX());
  float endy = getEndPointY();
  float counter = 3;
  float lx = 0;
  float ly = 0;

  try {
    //書き順1
    for (; startx < endx; startx=startx+counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) {return;}
    }

    //書き順1-2
    endx = getHalfPointX();
    endy = getHalfPointY();
    for(; startx < endx || starty < endy; startx=startx-counter+lx, starty=starty+counter-ly) {
      drawLine(startx, starty, cSize);
      lx=lx+(float)0.08;
      if(lx > counter) {
        ly = ly + (float)0.1;
      }
      if (breakCheck()) {return;}
    }
    //書き順1-3
    endy = getStartPointY() + (getHalfSizeY() / 2);
    for(; starty > endy; startx=startx-counter+lx, starty=starty+counter-ly) {
      drawLine(startx, starty, cSize);
      lx = lx - (float)0.08;
      ly = ly + (float)0.1;
      if (breakCheck()) {return;}
    }

    //書き順1-4
    endx = getEndPointX() - (getHalfSizeX() / 5);
    for(; startx < endx; startx=startx+counter, starty=starty+4) {
      drawLine(startx, starty, cSize);
      if(breakCheck()) {return;}
    }
 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}

/** ---------------------------------------
* void drawCharHU()
* ひらがな「ふ」の書き順を描画する
* @author YM 2012/06/21
* @return なし
*-----------------------------------------*/
public void drawCharHU()
{
  float startx = getHalfPointX();
  float starty = getStartPointY() + (getHalfSizeX() / 5);
  float endx = getStartPointX() + (getHalfSizeX());
  float endy = getStartPointY() + (getHalfSizeY() /2);
  float counter = 3;
  float lx = 0;

  try {
    //書き順1
    for (; starty < endy; startx=startx+2, starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) {return;}
    }

    //書き順2
    startx = getHalfPointX() - (getHalfSizeX() / 5);
    starty = getHalfPointY() - (getHalfSizeY() / 5);
    endy = getEndPointY() - (getHalfSizeY() / 10);
    for (; starty < endy; startx=startx+counter-lx, starty=starty+counter) {
      drawLine(startx, starty, cSize);
      lx = lx + (float)0.1;
      if (breakCheck()) {return;}
    }

    //書き順2-2
    endx = getHalfPointX() - (getHalfSizeX() / 5);
    for(; startx > endx; startx=startx-counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) {return;}
    }

    //書き順3
    startx = getStartPointX() + (getHalfSizeX() / 5);
    starty = getEndPointY() - (getHalfSizeY() / 5);
    endy = endy - (endy - (getHalfPointY() - (getHalfSizeY() / 5))) / 2;
    for(; starty > endy; startx=startx+2, starty=starty-counter) {
       drawLine(startx, starty, cSize);
       if (breakCheck()) {return;}
    }

    //書き順4
    startx = getEndPointX() - (getHalfSizeX() / 5);
    endy = getEndPointY() - (getHalfSizeY() / 10);
    lx = 0;
    for(; starty < endy; startx=startx+2 - lx, starty=starty+counter) {
       drawLine(startx, starty, cSize);
       lx = lx + (float)0.1;
       if (breakCheck()) {return;}
    }

 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}

  /** ---------------------------------------
* void drawCharHE()
* ひらがな「へ」の書き順を描画する
* @author YM 2012/06/21
* @return なし
*-----------------------------------------*/
public void drawCharHE()
{
  float startx = getStartPointX()+ (getHalfSizeX() / 10);
  float starty = getHalfPointY();
  float endx = getHalfPointX() + (getHalfSizeX() / 10);
  float endy = getStartPointY() + (getHalfSizeY() /2);
  float counter = 3;

  try {
    //書き順1
    for (; starty > endy; startx=startx+counter, starty=starty-counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) {return;}
    }

    endx = getEndPointX() - (getHalfSizeX() / 5);
    for (; startx < endx; startx=startx+counter, starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) {return;}
    }

 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}

  /** ---------------------------------------
* void drawCharHO()
* ひらがな「は」の書き順を描画する
* @author YM 2012/06/21-22
* @return なし
*-----------------------------------------*/
void drawCharHO()
{
  float startx = getStartPointX();
  float starty = getStartPointY();
  float endx = getEndPointX() - (getHalfSizeX() / 3);
  float endy = getEndPointY();
  float counter = 3;
  float lx = 0;
  float ly = 0;

  try {
    //書き順1
    for (; starty < endy; starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) {return;}
    }

    //書き順2
    startx = getStartPointX() + (getHalfSizeX() / 2);
    starty = getStartPointY();
    endx = getEndPointX() - (getHalfSizeX() / 4);
    for (; startx < endx; startx=startx+counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) { return; }
    }
    //書き順2
    startx = getStartPointX() + (getHalfSizeX() / 2);
    starty = getStartPointY() + (getHalfSizeY() / 2);
    endx = getEndPointX() - (getHalfSizeX() / 4);
    for (; startx < endx; startx=startx+counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) { return; }
    }

    //書き順3
    startx = getHalfPointX() + (getHalfSizeX() / 4);
    starty = getStartPointY();
    endy = getEndPointY() - (getHalfSizeY() / 2);
    for (; starty < endy; starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if (breakCheck()) {   return;  }
    }

    //書き順3-2
    endy = getEndPointY();
    lx = 0;
    ly = 0;
    float xcntr = 0;
    float cshy = starty;      //折り返し地点Y（下に振り下ろすポイント
    float cshx = startx + 1;  //折り返し制御（Xが現在地含む左側にいる場合
    for (; starty < endy; starty=starty+counter-ly, startx=startx-xcntr + lx) {
      drawLine(startx, starty, cSize);
      //よの、○部分を構成：xの微調整
      if(xcntr < counter+1.5) xcntr = xcntr + (float)0.5;
      lx = lx + (float)0.1;
      //よの、○部分を構成：振り下ろすタイミング調整
      if(starty >= cshy && startx <= cshx ) ly = ly +(float) 0.1;  //○の上部にくるまでは減速
      else ly = ly -(float) 0.2;                                   //○上部にきたため、振り下ろし
      if (breakCheck()) {   return;  }
    }
 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}
//class end
}

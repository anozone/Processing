package jp.ad.SOPaint.Win;

import processing.core.PApplet;

//--------------------------------------------------------
//「さ行」描画クラス
//--------------------------------------------------------
class DrawSALine extends DrawChar{

//コンストラクタ
public DrawSALine (float x, float y, float d, float c, ThreadHandle th, PApplet pa)
{
	super(th, pa);
  startPointX = x;
  startPointY = y;
  endPointX = startPointX + d;              //例 100 + 100 = 200
  endPointY = startPointY + d;
  halfSizeX = (endPointX - startPointX) / 2;    // (200 - 100) / 2 = 50
  halfSizeY = (endPointY - startPointY) / 2;
  halfPointX = startPointX + halfSizeX;         // 100 + 50 = 150
  halfPointY = startPointY + halfSizeY;
  dSize = d;
  cSize = c;
}

/*--------------------------------------------------------
// void drawCharSA()
// @return  なし
// @note    ひらがな「さ」の書き順を描画する
--------------------------------------------------------*/
public void drawCharSA()
{
    //--- 書き順 1 ---//
    float start  = getHalfPointX()-getHalfSizeX()/3;
    float endx   = getHalfPointX()+getHalfSizeX()/2;
    float endy   = startPointY*2;
    float nextx  = start;
    float nexty  = getHalfPointY()-getHalfSizeY()/2;
    float carve  = 0;
    float carve2  = 0;
    for(;nextx <= endx;nextx=nextx+3,nexty=nexty-(float)0.2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 3 ---//
    nexty  = getStartPointY();
    nextx  = getHalfPointX();
    endy   = getHalfPointY()+getHalfSizeY()/2;
    for(;nexty <= endy;nexty=nexty+3,nextx=nextx+(float)0.5){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 4 ---//
    nexty  = getHalfPointY() + getHalfSizeY()/2;
    nextx  = getHalfPointX() - getHalfSizeX() / 2;
    endy   = getEndPointY();
    carve = 0;
    for(;nexty <= endy;nexty=nexty+3,nextx=nextx+(carve=carve+(float)0.5)){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }
}
/*--------------------------------------------------------
// void drawCharSI()
// @return  なし
// @note    ひらがな「し」の書き順を描画する
--------------------------------------------------------*/
public void drawCharSI()
{
  //--- 書き順 1-1 ---//
  float endy   = getHalfPointY() + getHalfSizeY()/2;
  float nextx  = getHalfPointX();
  float nexty  = getHalfPointY() - getHalfSizeY()/2;
  float carve  = 0;
  for(;nexty <= endy;nexty=nexty+2){
    drawLine(nextx, nexty, cSize);
    if(breakCheck()){return;}
  }

  int deg = 180;
  int r   = 40;
  int x   = 0;
  int y   = 0;
  for(;deg >= 0;deg--){
     float rad = (float)(Math.toRadians(deg));
     x = (int)((nextx+40)+r*Math.cos(rad));  //角度から円周上のx座標を計算
     y = (int)((nexty)+r*Math.sin(rad));  //角度から円周上のy座標を計算
     drawLine(x, y, cSize);
     if(breakCheck()){return;}
  }

}
/*--------------------------------------------------------
// void drawCharSU()
// @return  なし
// @note    ひらがな「す」の書き順を描画する
--------------------------------------------------------*/
public void drawCharSU()
{
    //--- 書き順 1 ---//
    float endx    = getHalfPointX() + getHalfSizeX() / 2;
    float endy    = getHalfPointY() + getHalfSizeY() / 4;
    float nextx   = getHalfPointX() - getHalfSizeX() / 2;
    float nexty   = getHalfPointY() - getHalfSizeY() / 2;
    float carve   = 0;
    for(;nextx <= endx;nextx=nextx+3,nexty=nexty-(float)0.2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 2-1 ---//
    nextx   = getHalfPointX();
    nexty   = startPointY;
    for(;nexty <= endy;nexty=nexty+3,nextx=nextx-(carve=(carve+(float)0.005))){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 2-2 ---//
    //　円を描く //
    int deg = 45;
    int r   = 25;
    int x   = 0;
    int y   = 0;
    for(;deg <= 360;deg++){
      float rad = (float)(Math.toRadians(deg));
      x = (int)((nextx-17)+r*Math.cos(rad));  //角度から円周上のx座標を計算
      y = (int)((nexty-17)+r*Math.sin(rad));  //角度から円周上のy座標を計算
      drawLine(x, y, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 2-3 ---//
    nextx = (float)x;
    nexty = (float)y;
    endy  = getEndPointY() - getHalfSizeY() / 4;
    carve = 0;
    for(;nexty <= endy;nexty=nexty+1,nextx=nextx-(carve=(carve+(float)0.01))){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }
}
  /*--------------------------------------------------------
  // void drawCharSE()
  // @return  なし
  // @note    ひらがな「せ」の書き順を描画する
  --------------------------------------------------------*/
  public void drawCharSE()
  {
    //--- 書き順 1 ---//
    float endx    = getEndPointX();
    float endy    = getHalfPointY();
    float nextx   = getHalfPointX() - getHalfSizeX() / 2;
    float nexty   = getHalfPointY() - getHalfSizeY() / 2;
    for(;nextx <= endx;nextx=nextx+3,nexty=nexty-(float)0.2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 2-1 ---//
    nextx   = getHalfPointX() + getHalfSizeX() / 2;
    nexty   = startPointY;
    endy    = getHalfPointY();
    for(;nexty <= endy;nexty=nexty+3){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 2-2 ---//
    endx   = getHalfPointX() + getHalfSizeX() / 3;
    for(;nextx >= endx;nextx=nextx-3){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 3-1 ---//
    nextx   = getHalfPointX() - getHalfSizeX() / 4;
    nexty   = startPointY;
    endy    = getHalfPointY() + getHalfSizeY() / 2;
    for(;nexty <= endy;nexty=nexty+3){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 2-2 ---//
    endx   = endPointX;
    for(;nextx <= endx;nextx=nextx+3){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }
  }
  /*--------------------------------------------------------
  // void drawCharSO()
  // @return  なし
  // @note    ひらがな「そ」の書き順を描画する
  --------------------------------------------------------*/
  public void drawCharSO()
  {
    //--- 書き順 1 ---//
    float endx    = getHalfPointX() + getHalfSizeX() / 2;
    float endy    = startPointY*(float)1.4;
    float nextx   =  getHalfPointX() - getHalfSizeX() / 2;
    float nexty   =  getHalfPointY() - getHalfSizeY() / 4 * 3;
    float carve   = 0;
    for(;nextx <= endx;nextx=nextx+3,nexty=nexty-(float)0.2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 2 ---//
    endy    = getHalfPointY() - getHalfSizeY() / 4;
    for(;nexty <= endy;nexty=nexty+2,nextx=nextx-(carve=(carve+(float)0.3))){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    endx    = getHalfPointX() + getHalfSizeX() / 2;
    for(;nextx <= endx;nextx=nextx+3,nexty=nexty-(float)0.2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 2-2 ---//
    //　円を描く //
    int deg = 270;
    int r   = 60;
    int x   = 0;
    int y   = 0;
    for(;deg >= 100;deg--){
      float rad = (float)(Math.toRadians(deg));
      x = (int)((nextx)+r*Math.cos(rad));  //角度から円周上のx座標を計算
      y = (int)((nexty+60)+r*Math.sin(rad));  //角度から円周上のy座標を計算
      drawLine(x, y, cSize);
      if(breakCheck()){return;}
    }


  }
}




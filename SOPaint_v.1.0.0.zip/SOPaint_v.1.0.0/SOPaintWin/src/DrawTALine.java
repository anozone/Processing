package jp.ad.SOPaint.Win;

import processing.core.PApplet;

//--------------------------------------------------------
//「た行」描画クラス
//--------------------------------------------------------
class DrawTALine extends DrawChar{

/**
	 *
	 */
	private static final long serialVersionUID = 1L;
//コンストラクタ
public DrawTALine (float x, float y, float d, float c, ThreadHandle th, PApplet pa)
{
	super(th, pa);
  startPointX = x;
  startPointY = y;
  endPointX = startPointX + d;              //例 100 + 100 = 200
  endPointY = startPointY + d;
  halfSizeX = (endPointX - startPointX) / 2;    // (200 - 100) / 2 = 50
  halfSizeY = (endPointY - startPointY) / 2;
  halfPointX = startPointX + halfSizeX;         // 100 + 50 = 150
  halfPointY = startPointY + halfSizeY;
  dSize = d;
  cSize = c;
}

/*--------------------------------------------------------
// void drawCharTA()
*  @author KR
*  @author YM 2016/06/28
// @return  なし
// @note    ひらがな「た」の書き順を描画する
--------------------------------------------------------*/
public void drawCharTA()
{
    float fontsize=1;
    //フォントサイズの変更
    if(DEFAULT_SIZE > dSize){
       fontsize = dSize/DEFAULT_SIZE;
       startPointX = startPointX*fontsize;
       startPointY = startPointY*fontsize;
    }
    //--- 書き順 1 ---//
    float endx    = endPointX - (getHalfSizeX() / 2);
    float endy    = getEndPointY() - (getHalfSizeY() / 10);
    float nextx   = startPointX + (getHalfSizeX() / 4);
    float nexty   = getStartPointY()  + (getHalfSizeX() / 2) ;
    float carve2  = 0;
    for(;nextx <= endx;nextx=nextx+3,nexty=nexty-(float)0.2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }
    //--- 書き順 2 ---//
    nextx   = getHalfPointX() -  (getHalfSizeX() / 5);
    nexty   = startPointY;
    for(;nexty <= endy;nexty=nexty+3,nextx=nextx-(float)0.5){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //--- 書き順 3-1 ---//
    nextx  = getHalfPointX();
    nexty  = getHalfPointY();
    float end    = getHalfPointY() - (getHalfSizeY() /9);
    for(;nexty >= end ;nexty=nexty-((float)0.1*fontsize)){
       nextx = nexty <= end*0.75 ? nextx: nextx+(carve2=carve2+(float)0.005);
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }
    //--- 書き順 3-2 ---//
    carve2  = 0;
    end    = getEndPointX() - getHalfSizeX() / 10;
    for(;nextx <= end ;nextx=nextx+(1*fontsize)){
       nexty = nextx <= end*(float)0.75 ? nexty: nexty+(carve2=carve2+(float)0.005);
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //--- 書き順 4-1 ---//
    end    = getEndPointY() ;//+ (getHalfSizeY() /9);
    nextx  = getHalfPointX();
    nexty  = getEndPointY() - (getHalfSizeY() /9);
    carve2  = 0;

    for(;nexty <= end ;nexty=nexty+((float)0.1*fontsize)){
       nextx = nexty >= end*(float)0.75 ? nextx+(carve2=carve2+(float)0.005) : nextx;
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //--- 書き順 4-2 ---//
    carve2  = 0;
    end     =  getEndPointX() - getHalfSizeX() / 10;
    for(;nextx <= end ;nextx=nextx+(1*fontsize)){
       nexty = nextx <= end*0.75 ? nexty: nexty-(carve2=carve2+(float)0.005);
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }
}
/*--------------------------------------------------------
// void drawCharTI()
*  @author KR
*  @author YM 2016/06/28
// @return  なし
// @note    ひらがな「ち」の書き順を描画する
--------------------------------------------------------*/
public void drawCharTI()
{
 
    //-- 書き順 1 --//
    float endx    = endPointX - (getHalfSizeX() / 2);
    float endy    = getHalfPointY();
    float nextx   = startPointX + (getHalfSizeX() / 2);
    float nexty   = startPointY + (getHalfSizeY() / 2);
    for(;nextx <= endx;nextx=nextx+3,nexty=nexty-(float)0.2){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //-- 書き順 2-1 --//
    nextx    = getHalfPointX();;
    nexty    = startPointY + (getHalfSizeY() / 10);
    for(;nexty <= endy;nexty=nexty+3,nextx=nextx-(float)0.7){
      drawLine(nextx, nexty, cSize);
      if(breakCheck()){return;}
    }

    //　円を描く //
    int deg = 270;
    int r   = 50;
    int x   = 0;
    int y   = 0;
    for(;deg <= 450;deg++){
      float rad = (float)(Math.toRadians(deg));
      x = (int)((nextx)+r*Math.cos(rad));  //角度から円周上のx座標を計算
      y = (int)((nexty+50)+r*Math.sin(rad));  //角度から円周上のy座標を計算
      drawLine(x, y, cSize);
      if(breakCheck()){return;}
    }
}
/*--------------------------------------------------------
// void drawCharTU()
*  @author KR
*  @author YM 2016/06/28
// @return  なし
// @note    ひらがな「つ」の書き順を描画する
--------------------------------------------------------*/
public void drawCharTU()
{

    //-- 書き順 1 --//
    float endx    = endPointX - (getHalfSizeX() / 2);
    float nextx   = startPointX + (getHalfSizeX() / 10);
    float nexty   = getStartPointY() + (getHalfSizeY() / 2);

    for(;nextx <= endx ;nextx=nextx+2,nexty = nexty-(float)0.1){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //　円を描く //
    int deg = 270;
    int r   = 50;
    int x   = 0;
    int y   = 0;
    for(;deg <= 430;deg++){
      float rad = (float)(Math.toRadians(deg));
      x = (int)((nextx)+r*Math.cos(rad));  //角度から円周上のx座標を計算
      y = (int)((nexty+50)+r*Math.sin(rad));  //角度から円周上のy座標を計算
      drawLine(x, y, cSize);
      if(breakCheck()){return;}
    }

    endx    = getHalfPointX();
    nexty   = y;
    nextx   = x;
    for(;nextx >= endx ;nextx=nextx-2,nexty = nexty+(float)0.3){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }
}
/*--------------------------------------------------------
// void drawCharTE()
*  @author KR
*  @author YM 2016/06/28
// @return  なし
// @note    ひらがな「て」の書き順を描画する
--------------------------------------------------------*/
public void drawCharTE()
{
  
    //-- 書き順 1 --//
    float endx    = endPointX - (getHalfSizeX() / 2);
    float nextx   = startPointX + (getHalfSizeX() / 2);
    float nexty   = startPointY + (getHalfSizeY() / 2);

    for(;nextx <= endx ;nextx=nextx+2,nexty = nexty-(float)0.1){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }
    //　円を描く //
    int deg = 270;
    int r   = 70;
    int x   = 0;
    int y   = 0;
    for(;deg >= 90;deg--){
      float rad = (float)(Math.toRadians(deg));
      x = (int)((nextx)+r*Math.cos(rad));  //角度から円周上のx座標を計算
      y = (int)((nexty+70)+r*Math.sin(rad));  //角度から円周上のy座標を計算
      drawLine(x, y, cSize);
      if(breakCheck()){return;}
    }
}
/*--------------------------------------------------------
// void drawCharTO()
*  @author KR
*  @author YM 2016/06/28
// @return  なし
// @note    ひらがな「と」の書き順を描画する
--------------------------------------------------------*/
public void drawCharTO()
{

    //-- 書き順 1 --//
    float endx;
    float endy    = getHalfPointY();
    float nextx   = getHalfPointX() - (getHalfSizeX() / 10);
    float nexty   = getStartPointY() + (getHalfSizeY() / 10);
    for(;nexty <= endy ;nexty=nexty+3){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //-- 書き順 2 --//
    endy  = getHalfPointY() + (getHalfSizeY() / 4);
    nextx = getHalfPointX()+ (getHalfSizeX() / 2);
    nexty = getStartPointY() + (getHalfSizeY() / 2);
    for(;nexty <= endy ;nexty=nexty+2,nextx=nextx-(float)2.7){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //　円を描く //
    int deg = 200;
    int r   = 50;
    int x   = 0;
    int y   = 0;
    for(;deg >= 90;deg--){
      float rad = (float)(Math.toRadians(deg));
      x = (int)((nextx+50)+r*Math.cos(rad));  //角度から円周上のx座標を計算
      y = (int)((nexty+15)+r*Math.sin(rad));  //角度から円周上のy座標を計算
      drawLine(x, y, cSize);
      if(breakCheck()){return;}
    }

    endx  = getHalfPointX()+ (getHalfSizeX() / 2);
    nexty = y;
    nextx = x;
    for(;nextx <= endx ;nextx=nextx+3){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

}
}


package jp.ad.SOPaint.Win;

import processing.core.PApplet;

/** ---------------------------------------
* な行描画クラス
* @author YM 2012/06/25
*-----------------------------------------*/
class DrawNALine extends DrawChar{


/** ---------------------------------------
* DrawNALine(float, float, float, float)
* コンストラクタ
* @author YM 2012/06/25
* @param x 描画開始位置座標X
* @param y 描画開始位置座標Y
* @param d 描画する大きさ
* @param c 線の太さ
*-----------------------------------------*/
public DrawNALine (float x, float y, float d, float c, ThreadHandle th, PApplet pa)
  {
	super(th, pa);
  startPointX = x;
  startPointY = y;
  dSize = d;
  cSize = c;
  endPointX = startPointX + dSize;              //例 100 + 100 = 200
  endPointY = startPointY + dSize;
  halfSizeX = (endPointX - startPointX) / 2;    // (200 - 100) / 2 = 50
  halfSizeY = (endPointY - startPointY) / 2;
  halfPointX = startPointX + halfSizeX;         // 100 + 50 = 150
  halfPointY = startPointY + halfSizeY;
}

   /** ---------------------------------------
 * void drawCharNA()
 * ひらがな「な」の書き順を描画する
 * @author KR 2012/06/25
 * @author YM 2012/06/28
 * @return なし
 *-----------------------------------------*/
 public void drawCharNA()
 {
   //-- 書き順 1 --/
  float nextx  = startPointX + (getHalfSizeX() / 4);
  float nexty  = startPointY + (getHalfSizeY() / 2);
  float endx   = getHalfPointX();

  for(;nextx <= endx;nextx=nextx+3,nexty=nexty-(float)0.2){
     drawLine(nextx, nexty, cSize);
     if(breakCheck()){return;}
  }

  //-- 書き順 2 --/
  float endy   = getHalfPointY() + (getHalfSizeY() / 2);
  nexty  = startPointY + (getHalfSizeY() / 10);
  nextx  = getHalfPointX() - (getHalfSizeX() / 3);
  for(;nexty <= endy;nexty=nexty+3,nextx=nextx-(float)0.75){
     drawLine(nextx, nexty, cSize);
     if(breakCheck()){return;}
  }

  //-- 書き順 3 --/
  float carve   = 0;
  nexty  = startPointY + (getHalfSizeY() / 2);
  nextx  = getHalfPointX() + (getHalfSizeX() / 2);
  endy   = getHalfPointY() - (getHalfSizeY() / 10);
  for(;nexty <= endy;nexty=nexty+2,nextx=nextx+(carve=(carve+(float)0.1))){
     drawLine(nextx, nexty, cSize);
     if(breakCheck()){return;}
  }

  //-- 書き順 4 --//
  nexty  = getHalfPointY();
  nextx  = getHalfPointX();
  endy   = getEndPointY() - (getHalfSizeY() / 2);
  for(;nexty <= endy;nexty=nexty+2){
     drawLine(nextx, nexty, cSize);
     if(breakCheck()){return;}
  }
  int deg = 0;
  int r   = 25;
  int x   = 0;
  int y   = 0;
  for(;deg <= 270;deg++){
     float rad = (float)(Math.toRadians(deg));
     x = (int)((nextx-25)+r*Math.cos(rad));  //角度から円周上のx座標を計算
     y = (int)((nexty)+r*Math.sin(rad));  //角度から円周上のy座標を計算
     drawLine(x, y, cSize);
     if(breakCheck()){return;}
  }

  endx   = getEndPointX() - (getHalfSizeX() /(float) 1.5);
  carve  = 0;
  nextx  = nextx-25;
  nexty  = nexty-25;
  for(;nextx <= endx;nexty=nexty+(carve=(carve+(float)0.1)),nextx=nextx+2){
     drawLine(nextx, nexty, cSize);
     if(breakCheck()){return;}
  }
 }
 /** ---------------------------------------
 * void drawCharNI()
 * ひらがな「に」の書き順を描画する
 * @author KR 2012/06/25
 * @author YM 2012/06/27
 * @return なし
 *-----------------------------------------*/
 public void drawCharNI()
 {
    float fontsize=1;
    //フォントサイズの変更
    if(DEFAULT_SIZE > dSize){
       fontsize = dSize/DEFAULT_SIZE;
       startPointX = startPointX*fontsize;
       startPointY = startPointY*fontsize;
    }

    float nextx  = startPointX + (getHalfSizeX() / 5);
    float nexty  = startPointY;
    float end    = getEndPointY();
    for(;nexty <= end ;nexty=nexty+((float)0.8*fontsize)){
       nextx = end*0.70 > nexty ? nextx : nextx+((float)0.11*fontsize);
       nextx = end*0.80 > nexty ? nextx-((float)0.1*fontsize) : nextx;
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }


    //--- 書き順 1-1 ---//
     end     = getEndPointX() - (getHalfSizeY() / 5);
     nextx   = getStartPointX() + (getHalfSizeX() / 2);
     nexty   = startPointY + (getHalfSizeY() /2);
    // end = nextx +  (getHalfSizeX() / 10);
    // float end2 = nexty;



    for(;nextx < end;nextx=nextx+((float)3*fontsize)){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

    //--- 書き順 2-1 ---//
    end    = getEndPointX() - (getHalfSizeX() / 5);
    nextx  = getStartPointX() + (getHalfSizeX() / 2);
    nexty  = getEndPointY() - (getHalfSizeY() / 2);

    for(;nextx < end ;nextx=nextx+((float)3*fontsize)){
       drawLine(nextx, nexty, cSize);
       if(breakCheck()){return;}
    }

 }
  /** ---------------------------------------
 * void drawCharNU()
 * ひらがな「ぬ」の書き順を描画する
 * @author YM 2012/06/25
 * @return なし
 *-----------------------------------------*/
public void drawCharNU()
{
  float startx = getStartPointX() + (getHalfSizeX() / 2);
  float starty = getStartPointY() + (getHalfSizeY() / 4);
  float endx = getHalfPointX() + (getHalfSizeX() / 4);
  float endy = getEndPointY() - (getHalfSizeY() / 4);
  float counter = 3;
  float lx = 0;
  float ly = 0;

  try {
    //書き順1
    for (; starty < endy;startx=startx+1,starty=starty+counter) {
      drawLine(startx,starty, cSize);
      if (breakCheck()) { return; }
    }

    //書き順2
    startx = getHalfPointX() + (getHalfSizeX() / 4);
    starty = getStartPointY();
    for(; starty < endy;startx=startx-(float)1.5, starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()) { return; }
    }

    //書き順2-2
    endy = getHalfPointY() + (getHalfSizeY() / 6);
    for(; starty > endy; startx=startx-1, starty=starty-counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()) { return; }
    }

    //書き順2-3
    endy = getEndPointY() - (getHalfSizeY() / 4);
    lx = 0;
    boolean  flag = false;
    for(; starty < endy; startx=startx+counter+lx, starty=starty-3+ly) {
      drawLine(startx, starty, cSize);
      ly = ly + (float)0.08;
      if((startx > getEndPointX() - (getHalfSizeY() / 4) )&& !flag) {
        counter = (float)1.5;
        flag = true;
      } else if (flag) {          //折り返し部分
        lx = lx - (float)0.15;
        ly = ly + (float)0.02;
      }
      if(breakCheck()) { return; }
    }

    //書き順2-4
    endy = getEndPointY() - (getHalfSizeY() / 5);
    endx = startx;
    ly = 0;
    lx = 0;
    flag = false;
    for(; starty < endy || startx <= endx; startx=startx-3+lx, starty=starty+counter-ly) {
      drawLine(startx, starty, cSize);
      if(breakCheck()) { return; }
      if(ly <= counter*2 && !flag) {  //丸部分折り返し部分
        ly = ly+(float)0.5;
      } else if (ly > counter && !flag) {
        flag = true;
        lx = 6;
      } else {
        ly = ly -(float) 0.3;               //閉じ
      }
    }

  } catch (ArrayIndexOutOfBoundsException e) {
    println("OutOfBoundsError");
    e.printStackTrace();
  } catch (NullPointerException e) {
    println("NullPointerError");
    e.printStackTrace();
  } catch (OutOfMemoryError e) {
    println("OutOfMemoryError");
    e.printStackTrace();
  } catch (Exception e) {
    println("CriticalError");
    e.printStackTrace();
  }
}


  /** ---------------------------------------
* void drawCharNE()
* ひらがな「ね」の書き順を描画する
* @author YM 2012/06/25
* @return なし
*-----------------------------------------*/
public void drawCharNE()
{
  float startx = getStartPointX() + (getHalfSizeX() / 2);
  float starty = getStartPointY();
  float endx = getEndPointX();
  float endy = getEndPointY();
  float lx = 0;
  float ly = 0;
  float counter = 3;

  try {
     //書き順1
    for(;starty < endy; starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

    //書き順2
    endx = startx;
    startx = getStartPointX();
    starty = getStartPointY() + (getHalfSizeY() / 2);
    for (;startx <= endx; startx=startx+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()){return;}
    }

   //書き順2-2
   starty = getStartPointY() + (getHalfSizeY() / 2);
   endy = getHalfPointY() + (getHalfSizeY() / 2);
   for(;starty < endy; startx=startx-counter+1, starty=starty+counter){
     drawLine(startx, starty, cSize);
    if(breakCheck()){return;}
   }
   //書き順2-3
   endx =  getStartPointX() + (getHalfSizeX() / 2);
   for(;startx < endx; startx=startx+counter+(3/2), starty=starty-counter) {
     drawLine(startx, starty, cSize);
     if(breakCheck()){return;}
   }

   //書き順2-4
   for(;ly < counter*1.5;startx=startx+counter+(3/2)-lx, starty=starty-counter+ly) {
      drawLine(startx, starty, cSize);
      if(starty < getEndPointY() - getHalfSizeY()){ lx = lx +(float) 0.025;}
      else {lx = lx + (float)0.5;}
      ly = ly +(float) 0.15;
      if(breakCheck()){return;}
   }
   //書き順2-5
   endy = getEndPointY() - (getHalfSizeY() / 10);
   for(;starty < endy; starty=starty+counter, startx=startx+counter-lx) {
     drawLine(startx, starty, cSize);
     lx = lx +(float) 0.1;
     if(breakCheck()){return;}
   }

   //書き順2-6
   endx = startx;
   endy = getEndPointY();
   boolean flag = false;
   ly = 0;
   for(;starty < endy || startx <= endx; starty=starty+counter-ly, startx=startx+counter-lx) {
    drawLine(startx, starty, cSize);
    if(ly <= counter*2 && !flag) {       //○部分初期
      if(lx <= 6)lx = lx + (float)0.5;
      if(ly <= 6)ly = ly +(float) 0.5;
    } else if(ly > counter*2 && !flag) { //返しの部分
      flag = true;
      lx = 0;
    } else {                             //閉じ
      if(lx > 0) lx = lx -(float) 0.5;
      if(ly > 0) ly = ly -(float) 0.7;
    }
    if(breakCheck()) {return;}
   }

  //error処理
 } catch (ArrayIndexOutOfBoundsException e) {
   println("OutOfBoundsError");
   e.printStackTrace();
 } catch (NullPointerException e) {
   println("NullPointerError");
   e.printStackTrace();
 } catch (OutOfMemoryError e) {
   println("OutOfMemoryError");
   e.printStackTrace();
 } catch (Exception e) {
   println("CriticalError");
   e.printStackTrace();
 }
}

  /** ---------------------------------------
 * void drawCharNO()
 * ひらがな「の」の書き順を描画する
 * @author YM 2012/06/25
 * @return なし
 *-----------------------------------------*/
public void drawCharNO()
{
  float startx = getStartPointX() + (getHalfSizeX() / 2);
  float starty = getStartPointY() + (getHalfSizeY() / 4);
  float endy = getEndPointY() - (getHalfSizeY() / 4);
  float counter = 3;
  float ly = 0;

  try {
    //書き順1
    startx = getHalfPointX();
    starty = getStartPointY() + (getHalfSizeY() / (float)1.5);
    for(; starty < endy;startx=startx-(float)1.5, starty=starty+counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()) { return; }
    }

    //書き順1-2
    endy = getHalfPointY() + (getHalfSizeY() / 6);
    for(; starty > endy; startx=startx-1, starty=starty-counter) {
      drawLine(startx, starty, cSize);
      if(breakCheck()) { return; }
    }

    //書き順1-3
    endy = getEndPointY();
    boolean  flag = false;
    for(; starty < endy; startx=startx+counter, starty=starty-3+ly) {
      drawLine(startx, starty, cSize);
      ly = ly +(float) 0.08;
      if((startx > getEndPointX() - (getHalfSizeY() / 4) )&& !flag) {
        counter = (float)1.5;
        flag = true;
      } else if (flag) {          //折り返し部分
         counter = counter -(float) 0.1;
      }
      if(breakCheck()) { return; }
    }
  } catch (ArrayIndexOutOfBoundsException e) {
    println("OutOfBoundsError");
    e.printStackTrace();
  } catch (NullPointerException e) {
    println("NullPointerError");
    e.printStackTrace();
  } catch (OutOfMemoryError e) {
    println("OutOfMemoryError");
    e.printStackTrace();
  } catch (Exception e) {
    println("CriticalError");
    e.printStackTrace();
  }
}

//class end
}

